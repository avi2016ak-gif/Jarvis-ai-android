# JARVIS V3.3.11

- Updated Android app version to 3.3.11 (versionCode 43).
- Added an explicit Gradle version report in the cloud workflow.
- Added a Gradle project configuration (`gradle help`) validation step before tests and APK assembly.
- Preserved read-only repository permissions, build concurrency control, owner approval gate, and fail-closed task handling.
- This is source-only; no successful cloud APK build or physical-device validation is claimed.
