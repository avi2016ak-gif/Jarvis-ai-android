# JARVIS V3.3.7

- Added a GitHub Actions workflow to run the full test suite and build a debug APK with Gradle 8.9, Java 17, and Android SDK tooling.
- Added phone-friendly instructions for triggering the cloud build and retrieving its APK artifact.
- Updated the Android app's displayed and packaged version to 3.3.7 (versionCode 39).
- Preserved the Owner Permission Gate and fail-closed task-handler behavior.
- The cloud workflow is configured but has not yet been executed; no APK build success is claimed.
