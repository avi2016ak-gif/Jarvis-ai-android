# JARVIS V3.3.17

- Security/privacy packaging fix: removed test runtime `jarvis_memory.db` from the source archive. The included test record was synthetic, but runtime databases must not ship in source packages.
- Added preflight checks for runtime database and Python bytecode/cache artifacts.
- Android version metadata updated to 3.3.17 (versionCode 49).
- APK build and physical-device validation remain pending.
