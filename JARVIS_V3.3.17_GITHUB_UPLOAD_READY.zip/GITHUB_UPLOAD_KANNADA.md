# JARVIS V3.3.17 — GitHub upload (Kannada)

ಈ ZIP ಅನ್ನು repository root ಗೆ upload ಮಾಡಬೇಕು. ZIP ಒಳಗಿನ files/folders ಅನ್ನು 그대로 upload ಮಾಡಿ; `.github` folder ಕೂಡ ಇರಬೇಕು.

## GitHub ನಲ್ಲಿ
1. GitHub ನಲ್ಲಿ `avi2016ak-gif` account ತೆರೆಯಿರಿ.
2. **New repository** ಒತ್ತಿ.
3. Repository name: `Jarvis-android`
4. **Private** ಆಯ್ಕೆ ಮಾಡಿ, **Create repository** ಒತ್ತಿ.
5. Empty repository ಪುಟದಲ್ಲಿ **Add file → Upload files** ಆಯ್ಕೆಮಾಡಿ.
6. ಈ ZIP extract ಮಾಡಿದ ನಂತರ ಅದರ ಒಳಗಿನ ಎಲ್ಲ files/folders select ಮಾಡಿ upload ಮಾಡಿ. `android`, `jarvis`, `scripts`, `.github`, `README.md` root ಮಟ್ಟದಲ್ಲಿರಬೇಕು.
7. **Commit changes** ಒತ್ತಿ.
8. **Actions** tab → **JARVIS Android build** → **Run workflow**.
9. Workflow green ಆಗಿದರೆ run page ಕೆಳಗೆ **Artifacts** ನಲ್ಲಿ `jarvis-v3.3.17-debug-apk` download ಮಾಡಿ. ZIP extract ಮಾಡಿ `app-debug.apk` install ಮಾಡಿ.

## Build ಮಾಹಿತಿ
- Version: 3.3.17 (versionCode 49)
- APK: Debug/testing build; production signed release ಅಲ್ಲ.
- APK build ಮತ್ತು physical phone validation ಇನ್ನೂ ಆಗಿಲ್ಲ.
- API keys/passwords/private user data repository ಗೆ ಹಾಕಬೇಡಿ.
