import os,tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings
fd,p=tempfile.mkstemp(); os.close(fd)
j=Jarvis(Settings(db_path=p,owner_id='owner'))
try:
    assert j.VERSION == '3.1'  # compatibility test carried forward
    r=j.respond('owner','status')
    assert r.intent=='status'
    ctx=j.session_context('owner')
    assert len(ctx)>=2 and ctx[-2]['role']=='user' and ctx[-1]['role']=='assistant'
    try: j.session_context('bad'); raise AssertionError('security failed')
    except PermissionError: pass
    j.clear_session('owner'); assert j.session_context('owner')==[]
    assert j.status()['sessions']=='ready'
    print('JARVIS V2.9 TEST: PASS')
finally:
    j.shutdown(); os.remove(p)
