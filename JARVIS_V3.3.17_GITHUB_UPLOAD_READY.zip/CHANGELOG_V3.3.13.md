# JARVIS V3.3.13

- Android/Python bridge now renders research result objects as readable plain text with source URLs and short excerpts.
- Research display explicitly labels the existing lexical source-overlap check as a rough check, not independent fact verification.
- Dict/list status and health results are formatted as readable JSON instead of Python object representations.
- Android metadata updated to versionName 3.3.13 / versionCode 45; cloud artifact label updated.
- Source-only change. APK build and physical-device validation remain pending.
