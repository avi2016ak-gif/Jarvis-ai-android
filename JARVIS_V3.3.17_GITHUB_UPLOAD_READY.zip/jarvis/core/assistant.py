from jarvis.config.settings import Settings
from jarvis.memory.store import MemoryStore
from jarvis.security.policy import SecurityPolicy
from jarvis.security.audit import AuditLog
from jarvis.tasks.runner import TaskRunner
from jarvis.research.engine import ResearchEngine
from jarvis.automation.scheduler import Scheduler
from jarvis.voice.wakeword import WakeWordDetector
from jarvis.voice.runtime import VoiceRuntime
from jarvis.core.autonomy import AutonomousExecutor
from jarvis.core.autonomous import AutonomousOrchestrator
from jarvis.core.multimodal import MultimodalGateway
from jarvis.core.vision import VisionGateway
from jarvis.core.router import CommandRouter
from jarvis.core.orchestrator import Orchestrator
from jarvis.core.providers import ProviderRegistry
from jarvis.core.health import HealthMonitor
from jarvis.core.session import SessionManager
from jarvis.ai.orchestrator import AIOrchestrator
class Jarvis:
    VERSION='3.1'
    def __init__(self,settings=None):
        self.settings=settings or Settings(); self.memory=MemoryStore(self.settings.db_path); self.security=SecurityPolicy(self.settings.owner_id); self.audit=AuditLog(); self.tasks=TaskRunner(self.security,audit=self.audit); self.research=ResearchEngine(); self.scheduler=Scheduler(); self.wakeword=WakeWordDetector(self.settings.wake_word); self.providers=ProviderRegistry(); self.health=HealthMonitor(); self.sessions=SessionManager(); self.ai=AIOrchestrator(self.providers); self.router=CommandRouter(self); self.orchestrator=Orchestrator(self); self.autonomy=AutonomousExecutor(self); self.autonomous_orchestrator=AutonomousOrchestrator(self); self.multimodal=MultimodalGateway(); self.vision=VisionGateway(); self.voice=VoiceRuntime(self); self.health.register('memory',lambda: self.memory.get('__health__') is None); self.health.register('security',lambda: self.security.authorize(self.settings.owner_id,'health')); self.health.register('scheduler',lambda:True)
    def status(self):return {'name':self.settings.name,'version':self.VERSION,'build_version':self.VERSION,'runtime_version':self.VERSION, 'autonomy':'ready', 'voice_runtime':'ready','vision':'ready','multimodal':'ready','wake_word':self.settings.wake_word,'memory':'ready','security':'owner-only','task_runner':'ready','research':'ready','scheduler':'ready','wakeword':'ready','router':'ready','orchestrator':'ready','providers':self.providers.names(),'compatibility':'v2.1-v3.1','sessions':'ready','ai_provider':self.ai.primary.name}
    def health_status(self):return [{'name':r.name,'ok':r.ok,'detail':r.detail} for r in self.health.run()]
    def remember(self,key,value):self.memory.set(key,value)
    def recall(self,key):return self.memory.get(key)
    def execute(self,actor_id,action,fn,*args,**kwargs):return self.tasks.run(actor_id,action,fn,*args,**kwargs)
    def respond(self,actor_id,text):
        if not self.security.authorize(actor_id,'respond'):raise PermissionError('JARVIS action denied')
        if self.wakeword.detect(text):text=self.wakeword.strip_wake_word(text)
        self.audit.record(actor_id,'respond',True); self.sessions.record(actor_id,'user',text); result=self.orchestrator.handle(actor_id,text); self.sessions.record(actor_id,'assistant',result.result if hasattr(result,'result') else result); return result
    def autonomous(self,actor_id,text):
        if not self.security.authorize(actor_id,'autonomous'): raise PermissionError('JARVIS action denied')
        self.audit.record(actor_id,'autonomous',True)
        return self.autonomous_orchestrator.execute(actor_id,text)
    def inspect_media(self,actor_id,kind,data,metadata=None):
        if not self.security.authorize(actor_id,'inspect_media'): raise PermissionError('JARVIS action denied')
        result = self.vision.inspect(kind,data,metadata); return {'kind':result.kind,'analyzed':result.analyzed,'provider':result.provider,'result':result.result,'sha256':result.sha256}
    def voice_text(self,actor_id,text):
        return self.voice.process_text(actor_id,text)

    def _respond_direct(self,actor_id,text):
        if text.lower().strip().startswith('research '):return self.research.search(text[9:].strip())
        return self.ai.chat(actor_id,text,self.sessions.context(actor_id))['text']
    def session_context(self,actor_id,limit=10):
        if not self.security.authorize(actor_id,'session_context'): raise PermissionError('JARVIS action denied')
        return self.sessions.context(actor_id,limit)
    def clear_session(self,actor_id):
        if not self.security.authorize(actor_id,'clear_session'): raise PermissionError('JARVIS action denied')
        self.sessions.clear(actor_id)
    def shutdown(self):self.scheduler.shutdown();self.tasks.shutdown();self.orchestrator.shutdown();self.memory.close()
