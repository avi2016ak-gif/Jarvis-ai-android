import os,tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings

fd,p=tempfile.mkstemp(); os.close(fd)
j=Jarvis(Settings(db_path=p,owner_id='owner'))
try:
    assert tuple(map(int, j.VERSION.split("."))) >= (2, 8)
    assert j.autonomous('owner','remember language=Kannada + English') is True
    assert j.autonomous('owner','recall language') == 'Kannada + English'
    assert j.autonomous('owner','run status')['security'] == 'owner-only'
    assert j.voice_text('owner','hello there') is None
    turn=j.voice_text('owner','Hey Jarvis status')
    assert turn is not None and turn.command == 'status'
    try: j.autonomous('bad','run status'); raise AssertionError('security failed')
    except PermissionError: pass
    print('JARVIS V2.6 TEST: PASS')
finally:
    j.shutdown(); os.remove(p)
