from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings

def test_v23_orchestration_and_memory():
    j=Jarvis(Settings(db_path=":memory:", owner_id="owner"))
    try:
        assert tuple(map(int, j.status()["build_version"].split("."))) >= (2, 8)
        assert j.respond("owner", "hey jarvis remember city=Kudligi") .result is True
        assert j.respond("owner", "hey jarvis recall city").result == "Kudligi"
        f=j.orchestrator.submit("owner", "hello")
        assert f.result().intent == "chat"
    finally:
        j.shutdown()
