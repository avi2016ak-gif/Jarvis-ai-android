import tempfile
from pathlib import Path

import android_bridge


def test_android_bridge_uses_requested_private_database_directory():
    with tempfile.TemporaryDirectory() as tmp:
        try:
            ready = android_bridge.initialize(tmp)
            assert ready == "JARVIS V3.1 ready"
            answer = android_bridge.respond("status")
            assert "version" in answer and "3.1" in answer
            assert (Path(tmp) / "jarvis_memory.db").exists()
        finally:
            android_bridge.shutdown()


def test_android_bridge_rejects_use_before_initialization():
    android_bridge.shutdown()
    try:
        android_bridge.respond("status")
    except RuntimeError as exc:
        assert "not been initialized" in str(exc)
    else:
        raise AssertionError("bridge must reject requests before initialization")


def test_research_result_format_warns_about_rough_verification_and_shows_sources():
    from jarvis.research.models import ResearchResult, ResearchSource
    result = ResearchResult(
        "test question", "summary excerpt",
        [ResearchSource("Source One", "https://example.org", "evidence excerpt", 0.5)],
        True,
    )
    formatted = android_bridge._format_result(result)
    assert "Source-overlap check: PASS (rough lexical check only)" in formatted
    assert "not independent fact verification" in formatted
    assert "https://example.org" in formatted
    assert "evidence excerpt" in formatted
