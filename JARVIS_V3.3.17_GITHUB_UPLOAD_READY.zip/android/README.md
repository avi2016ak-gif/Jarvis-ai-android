# JARVIS Android V3.3.17

This is the Android source project for the JARVIS V3.3 Python core, embedded with Chaquopy. Version metadata is 3.3.17 (versionCode 49). It is source code, **not a compiled APK**.

## Build requirements
- Android Studio, Android SDK 35, and JDK 17
- Gradle 8.9-compatible Android Gradle Plugin 8.7.3
- Internet access for dependency downloads

Open this `android/` folder in Android Studio and run `app` > `assembleDebug`. The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Included app features
- Native Android chat screen with embedded Python 3.10 core and app-private SQLite memory
- Android INTERNET permission added for web research/network-based providers; cleartext HTTP remains disabled
- First-run 6–12 digit PIN setup; salted PBKDF2-HMAC-SHA256 (210,000 iterations)
- Failed PIN attempts and 30-second lockout stored in app-private preferences
- Kannada/English speech recognition and text-to-speech toggle; no always-on wake-word service
- Local notes and reminders, stored in app-private SharedPreferences
- Explicit owner approval for note/reminder save, edit, cancel, and background-task requests; approval requires re-entering the app PIN
- Single pending action, five-minute approval expiry, and fail-closed handling of unknown task types
- Reminder scheduling with WorkManager and local notifications; Android 13+ notification permission is required, and power management may delay delivery

## Local task commands
- `note: <text>`
- `remind: yyyy-MM-dd HH:mm | <text>` — uses the phone's local timezone
- `edit reminder: <id> | yyyy-MM-dd HH:mm | <new text>`
- `cancel reminder: <id>`
- `show notes`, `show reminders`, `task history`, `task status`
- `background: <description>` — requires approval, then queues a worker that currently reports `BLOCKED_HANDLER_NOT_CONFIGURED`; it does not execute arbitrary text or perform background research yet

After a protected command, press **ಅನುಮೋದಿಸು** and re-enter the owner PIN, or press **ನಿರಾಕರಿಸು**. A second pending action cannot replace the first.

## Security and limitations
The PIN is a local app access barrier, not a complete owner identity system. The app still needs Android Keystore-backed credential protection, independent owner-controlled shutdown/lock, security review, and penetration testing. Pending approvals are memory-only and are discarded when the app process restarts. Unknown task types are blocked; no free-form task text is interpreted as code. External messaging, transactions, self-modification, always-on wake word, camera integration, and production background handlers are not enabled.

## Tests and validation
- Android offline preflight: run `python scripts/android_preflight.py` from the project root. It checks required Android files, pinned build plugins, runtime/version metadata, manifest security settings, fail-closed task dispatch, and Kotlin test-source presence. It does not compile Kotlin or build an APK. Run `python scripts/android_build_diagnostics.py` to check whether Gradle and Android SDK prerequisites are present; a blocked result means APK build cannot be attempted in that environment.
- Python core/bridge test suite: run `./scripts/run_tests.sh` from the project root. The helper configures the bridge import path and runs pytest plus legacy scripts.
- Kotlin unit tests are included under `app/src/test` for the owner gate, task registry, local handlers, and reminder parser.
- V3.3.7 adds a standalone Kotlin safety-core compile/runtime smoke test; V3.3.12 makes the cloud workflow explicitly install Android SDK Platform 35 and Build Tools 35.0.0, and runs Android Gradle unit tests before assembling the APK. V3.3.13 formats research output for phone readability and labels its source-overlap check cautiously; V3.3.15 adds a manual lock button that clears transient interaction content and returns to PIN authentication; V3.3.5 corrects the visible app version label and adds an offline Android build-readiness diagnostic. This source update has not been built with Gradle/Android SDK or tested on a physical Android phone in this environment. Do not treat it as a finished APK or production-validated app.


## Cloud APK build

A GitHub Actions workflow is included at `.github/workflows/android-build.yml`. It runs
the test suite, invokes Gradle 8.9 with Java 17 and the Android SDK, and uploads a debug
APK artifact. See the repository-root `BUILD_ON_GITHUB.md` for phone-friendly setup steps.
This workflow has not been run from this environment; a successful remote run is still
required before claiming that an APK has been built.
