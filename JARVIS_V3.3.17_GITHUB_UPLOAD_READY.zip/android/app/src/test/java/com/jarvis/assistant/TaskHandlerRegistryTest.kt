package com.jarvis.assistant

import org.junit.Assert.*
import org.junit.Test

class TaskHandlerRegistryTest {
    private fun action(type: String = "LOCAL_NOTE") =
        ProtectedAction(type, "Test task", 1L)

    @Test fun unknownTaskTypeIsBlocked() {
        val result = TaskHandlerRegistry().execute(action("SHELL_COMMAND"))
        assertFalse(result.successful)
        assertEquals(TaskHandlerRegistry.STATUS_BLOCKED_NO_HANDLER, result.status)
    }

    @Test fun onlyExplicitlyRegisteredHandlerCanRun() {
        var called = false
        val registry = TaskHandlerRegistry(
            mapOf("LOCAL_NOTE" to ApprovedTaskHandler {
                called = true
                TaskExecutionResult(true, "COMPLETED", "Saved locally")
            })
        )
        val result = registry.execute(action())
        assertTrue(called)
        assertTrue(result.successful)
        assertEquals("COMPLETED", result.status)
    }

    @Test fun handlerExceptionIsNotReportedAsSuccess() {
        val registry = TaskHandlerRegistry(
            mapOf("LOCAL_NOTE" to ApprovedTaskHandler { throw IllegalStateException("failure") })
        )
        val result = registry.execute(action())
        assertFalse(result.successful)
        assertEquals(TaskHandlerRegistry.STATUS_HANDLER_ERROR, result.status)
    }

    @Test fun blankTaskTypeIsRejected() {
        val result = TaskHandlerRegistry().execute(action("  "))
        assertFalse(result.successful)
        assertEquals(TaskHandlerRegistry.STATUS_REJECTED, result.status)
    }
}
