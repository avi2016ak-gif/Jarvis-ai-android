package com.jarvis.assistant

import org.junit.Assert.*
import org.junit.Test

class OwnerPermissionGateTest {
    @Test fun secondRequestCannotReplacePendingAction() {
        var now = 1_000L
        val gate = OwnerPermissionGate(nowMillis = { now })
        assertTrue(gate.request("DELETE_DATA", "Delete local memory").contains("OWNER APPROVAL REQUIRED"))
        assertTrue(gate.request("EXTERNAL_COMMUNICATION", "Send message").contains("ALREADY PENDING"))
        assertEquals("Delete local memory", gate.pendingDescription())
        assertEquals("DELETE_DATA", gate.approve()?.type)
        assertNull(gate.pendingDescription())
    }

    @Test fun approvalExpiresAfterFiveMinutes() {
        var now = 10_000L
        val gate = OwnerPermissionGate(nowMillis = { now }, expiryMillis = 300_000L)
        gate.request("BACKGROUND_TASK", "Run report")
        now += 300_001L
        assertNull(gate.approve())
    }

    @Test fun approvalIsSingleUse() {
        val gate = OwnerPermissionGate(nowMillis = { 1_000L })
        gate.request("BACKGROUND_TASK", "Run report")
        assertNotNull(gate.approve())
        assertNull(gate.approve())
    }

    @Test fun denialClearsPendingAction() {
        val gate = OwnerPermissionGate(nowMillis = { 1_000L })
        gate.request("DELETE_DATA", "Delete local memory")
        assertTrue(gate.deny())
        assertFalse(gate.deny())
        assertNull(gate.pendingDescription())
    }
}
