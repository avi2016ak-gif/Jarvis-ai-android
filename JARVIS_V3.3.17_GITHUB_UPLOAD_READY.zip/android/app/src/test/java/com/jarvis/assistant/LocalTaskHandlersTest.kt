package com.jarvis.assistant

import org.junit.Assert.*
import org.junit.Test

class LocalTaskHandlersTest {
    private class FakeStore : LocalTaskStore {
        val records = mutableListOf<Triple<String, String, Long>>()
        override fun append(kind: String, value: String, createdAtMillis: Long): String {
            records += Triple(kind, value, createdAtMillis)
            return "test-id"
        }
        override fun list(kind: String): List<String> = records.filter { it.first == kind }.map { it.second }
    }

    @Test fun savesNoteOnlyWhenExplicitlyDispatched() {
        val store = FakeStore()
        val result = LocalTaskHandlers(store) { 123L }.asRegistry().execute(
            ProtectedAction(LocalTaskHandlers.TYPE_SAVE_NOTE, "Buy milk", 0L)
        )
        assertTrue(result.successful)
        assertEquals("SAVED_LOCAL", result.status)
        assertEquals(listOf("Buy milk"), store.list(LocalTaskHandlers.TYPE_SAVE_NOTE))
        assertEquals(123L, store.records.single().third)
    }

    @Test fun savesReminderRecordForTaskManagerScheduling() {
        val store = FakeStore()
        val result = LocalTaskHandlers(store).asRegistry().execute(
            ProtectedAction(LocalTaskHandlers.TYPE_SAVE_REMINDER, "Call the clinic", 0L)
        )
        assertTrue(result.successful)
        assertTrue(result.detail.contains("notification scheduling is handled"))
        assertEquals(listOf("Call the clinic"), store.list(LocalTaskHandlers.TYPE_SAVE_REMINDER))
    }

    @Test fun rejectsBlankContent() {
        val result = LocalTaskHandlers(FakeStore()).asRegistry().execute(
            ProtectedAction(LocalTaskHandlers.TYPE_SAVE_NOTE, "   ", 0L)
        )
        assertFalse(result.successful)
        assertEquals("REJECTED_INVALID_CONTENT", result.status)
    }

    @Test fun rejectsUnknownTaskAndDoesNotWriteAnything() {
        val store = FakeStore()
        val result = LocalTaskHandlers(store).asRegistry().execute(ProtectedAction("RUN_SHELL", "echo hi", 0L))
        assertFalse(result.successful)
        assertTrue(store.records.isEmpty())
    }
}
