package com.jarvis.assistant

import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class ReminderSpecTest {
    private val zone = ZoneId.of("Asia/Kolkata")
    private val now = LocalDateTime.of(2030, 1, 1, 10, 0).atZone(zone).toInstant().toEpochMilli()

    @Test fun parsesExplicitFutureLocalTime() {
        val parsed = ReminderSpec.parse("2030-01-01 11:30 | Take medicine", now, zone)
        assertNotNull(parsed)
        assertEquals("Take medicine", parsed!!.message)
        assertEquals("2030-01-01 11:30", parsed.displayTime)
    }

    @Test fun rejectsMissingSeparatorOrInvalidDate() {
        assertNull(ReminderSpec.parse("tomorrow take medicine", now, zone))
        assertNull(ReminderSpec.parse("2030-99-99 11:30 | test", now, zone))
    }

    @Test fun rejectsPastOrTooSoonReminder() {
        assertNull(ReminderSpec.parse("2030-01-01 10:00 | test", now, zone))
        assertNull(ReminderSpec.parse("2030-01-01 10:00 | test", now - 30_000, zone))
    }

    @Test fun rejectsBlankMessage() {
        assertNull(ReminderSpec.parse("2030-01-01 11:30 |   ", now, zone))
    }
}
