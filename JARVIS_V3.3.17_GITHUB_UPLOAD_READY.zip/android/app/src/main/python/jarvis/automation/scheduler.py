from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from threading import Event, Thread, Lock
import time, uuid

@dataclass(frozen=True)
class ScheduledTask:
    name: str
    run_at: datetime
    task_id: str

class Scheduler:
    def __init__(self, tick_seconds=0.05):
        self._items=[]; self._lock=Lock(); self._stop=Event(); self._tick=tick_seconds
        self._thread=Thread(target=self._loop, daemon=True, name="jarvis-scheduler"); self._thread.start()
    def schedule(self, name, delay_seconds, callback):
        item=(datetime.now(timezone.utc)+timedelta(seconds=max(0,delay_seconds)), name, callback, uuid.uuid4().hex)
        with self._lock: self._items.append(item)
        return ScheduledTask(item[1], item[0], item[3])
    def cancel(self, task_id):
        with self._lock:
            old=len(self._items); self._items=[x for x in self._items if x[3] != task_id]
            return len(self._items) != old
    def pending(self):
        with self._lock: return [ScheduledTask(n,t,i) for t,n,_,i in self._items]
    def shutdown(self):
        self._stop.set(); self._thread.join(timeout=2)
    def _loop(self):
        while not self._stop.is_set():
            now=datetime.now(timezone.utc)
            with self._lock:
                due=[x for x in self._items if x[0] <= now]; self._items=[x for x in self._items if x[0] > now]
            for _,_,cb,_ in due:
                try: cb()
                except Exception: pass
            time.sleep(self._tick)
