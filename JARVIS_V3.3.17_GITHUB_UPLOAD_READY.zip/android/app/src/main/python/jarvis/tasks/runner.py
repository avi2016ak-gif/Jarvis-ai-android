from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from typing import Any
import uuid
@dataclass
class TaskResult:
    ok:bool; value:Any=None; error:str|None=None
class TaskRunner:
    def __init__(self,security,max_workers=4,audit=None): self.security=security; self.executor=ThreadPoolExecutor(max_workers=max_workers,thread_name_prefix='jarvis-task'); self.audit=audit; self._futures={}
    def _allow(self,actor,action):
        ok=self.security.authorize(actor,action)
        if self.audit:self.audit.record(actor,action,ok)
        if not ok:raise PermissionError('JARVIS action denied')
    def run(self,actor_id,action,fn,*args,**kwargs): self._allow(actor_id,action); return fn(*args,**kwargs)
    def submit(self,actor_id,action,fn,*args,**kwargs):
        self._allow(actor_id,action); task_id=uuid.uuid4().hex; future=self.executor.submit(fn,*args,**kwargs); setattr(future, 'task_id', task_id); self._futures[task_id]=future; return future
    def result(self,task_id):
        f=self._futures.get(task_id)
        if f is None:return TaskResult(False,error='Unknown task')
        try:return TaskResult(True,value=f.result())
        except Exception as exc:return TaskResult(False,error=f'{type(exc).__name__}: {exc}')
    def cancel(self,actor_id,action,task_id): self._allow(actor_id,action); f=self._futures.get(task_id); return bool(f and f.cancel())
    def safe_run(self,actor_id,action,fn,*args,**kwargs):
        try:return TaskResult(True,self.run(actor_id,action,fn,*args,**kwargs))
        except Exception as exc:return TaskResult(False,error=f'{type(exc).__name__}: {exc}')
    def shutdown(self): self.executor.shutdown(wait=True,cancel_futures=True)
