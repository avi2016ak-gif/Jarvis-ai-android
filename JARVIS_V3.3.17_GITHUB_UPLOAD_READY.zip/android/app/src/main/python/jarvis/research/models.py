from dataclasses import dataclass, field
from typing import List

@dataclass
class ResearchSource:
    title: str
    url: str
    excerpt: str = ""
    reliability: float = 0.0

@dataclass
class ResearchResult:
    question: str
    answer: str
    sources: List[ResearchSource] = field(default_factory=list)
    verified: bool = False
