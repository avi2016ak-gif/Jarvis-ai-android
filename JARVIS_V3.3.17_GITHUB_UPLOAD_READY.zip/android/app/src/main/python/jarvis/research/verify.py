"""Deterministic source agreement and quality scoring for research results."""
import re
from collections import Counter

def _terms(text):
    return set(re.findall(r'\b[a-z]{5,}\b', (text or '').lower()))

def verify_sources(sources):
    if len(sources) < 2: return {'verified': False, 'agreement': 0.0, 'reason': 'Need at least two sources'}
    term_sets=[_terms(s.excerpt) for s in sources]
    pairs=[]
    for i in range(len(term_sets)):
        for j in range(i+1,len(term_sets)):
            union=term_sets[i] | term_sets[j]
            pairs.append(len(term_sets[i]&term_sets[j])/len(union) if union else 0.0)
    agreement=sum(pairs)/len(pairs)
    return {'verified': agreement >= 0.08, 'agreement': round(agreement,3), 'reason':'multi-source lexical agreement'}
