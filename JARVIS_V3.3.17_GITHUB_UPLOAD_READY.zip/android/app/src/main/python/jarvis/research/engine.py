from dataclasses import dataclass
from html import unescape
import re
from urllib.parse import quote,urljoin
from urllib.request import Request,urlopen
from .models import ResearchResult,ResearchSource
from .verify import verify_sources
@dataclass
class ResearchEngine:
    user_agent:str='JARVIS/2.5'; timeout:float=10.0
    def _fetch(self,url):
        req=Request(url,headers={'User-Agent':self.user_agent,'Accept-Language':'en-US,en;q=0.8'})
        with urlopen(req,timeout=self.timeout) as r:return r.read().decode('utf-8','ignore')
    def _clean(self,html):
        html=re.sub(r'<script[^>]*>.*?</script>|<style[^>]*>.*?</style>',' ',html,flags=re.I|re.S); return re.sub(r'\s+',' ',unescape(re.sub(r'<[^>]+>',' ',html))).strip()
    def _links(self,html,base):
        for href,title in re.findall(r'<a[^>]+href=[\'\"]([^\'\"]+)[\'\"][^>]*>(.*?)</a>',html,re.I|re.S):
            url=urljoin(base,href); label=self._clean(title)
            if url.startswith('http') and label and 'google.' not in url and 'bing.' not in url and 'duckduckgo.' not in url:yield label,url
    def search(self,question,limit=5):
        question=question.strip()
        if not question:return ResearchResult(question,'Empty research question.',[],False)
        sources=[]; seen=set(); errors=[]; q=quote(question)
        for engine,url in [('DuckDuckGo',f'https://html.duckduckgo.com/html/?q={q}'),('Bing',f'https://www.bing.com/search?q={q}&count=10')]:
            try:
                html=self._fetch(url)
                for label,link in self._links(html,url):
                    if link in seen:continue
                    seen.add(link)
                    try:page=self._clean(self._fetch(link))[:1800]
                    except Exception:continue
                    if len(page)>=80:sources.append(ResearchSource(label or link,link,page,0.50))
                    if len(sources)>=limit:break
            except Exception as exc:errors.append(f'{engine}: {type(exc).__name__}')
            if len(sources)>=limit:break
        if not sources:return ResearchResult(question,'Research unavailable: '+('; '.join(errors) or 'no usable sources'),[],False)
        verification=verify_sources(sources[:limit]); return ResearchResult(question,sources[0].excerpt,sources[:limit],verification['verified'])
    @staticmethod
    def _cross_source_consistency(sources):
        if len(sources)<2:return False
        a=set(re.findall(r'\b[a-z]{5,}\b',sources[0].excerpt.lower()))
        return bool(a) and any(len(a&set(re.findall(r'\b[a-z]{5,}\b',s.excerpt.lower())))>=3 for s in sources[1:3])
