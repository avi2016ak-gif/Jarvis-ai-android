from abc import ABC, abstractmethod

class SpeechToText(ABC):
    @abstractmethod
    def transcribe(self, audio): ...

class TextToSpeech(ABC):
    @abstractmethod
    def speak(self, text: str): ...
