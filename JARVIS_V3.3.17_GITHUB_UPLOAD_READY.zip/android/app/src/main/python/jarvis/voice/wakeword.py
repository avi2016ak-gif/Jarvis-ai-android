class WakeWordDetector:
    def __init__(self, wake_word="hey jarvis"): self.wake_word=wake_word.casefold().strip()
    def detect(self, text): return self.wake_word in (text or "").casefold()
    def strip_wake_word(self, text):
        if not text: return ""
        low=text.casefold(); i=low.find(self.wake_word)
        return (text[:i] + text[i+len(self.wake_word):]).strip() if i >= 0 else text.strip()
