"""Hands-free voice runtime. Providers are injectable for production deployments/tests."""
from dataclasses import dataclass
from typing import Optional
from .wakeword import WakeWordDetector

@dataclass
class VoiceTurn:
    heard: str
    command: str
    response: object
    spoken: object

class VoiceRuntime:
    def __init__(self, jarvis, stt=None, tts=None, wake_word=None):
        self.jarvis = jarvis
        self.stt = stt
        self.tts = tts
        self.wakeword = WakeWordDetector(wake_word or jarvis.settings.wake_word)

    def process_text(self, actor_id: str, text: str) -> Optional[VoiceTurn]:
        if not self.wakeword.detect(text):
            return None
        command = self.wakeword.strip_wake_word(text)
        result = self.jarvis.respond(actor_id, command)
        response = result.result if hasattr(result, "result") else result
        spoken = self.tts.speak(self._format(response)) if self.tts else {"spoken": False, "text": self._format(response)}
        return VoiceTurn(text, command, response, spoken)

    def process_audio(self, actor_id: str, audio):
        if not self.stt:
            raise RuntimeError("No STT provider configured")
        return self.process_text(actor_id, self.stt.transcribe(audio))

    @staticmethod
    def _format(value):
        if isinstance(value, (dict, list, tuple)):
            return str(value)
        return str(value)
