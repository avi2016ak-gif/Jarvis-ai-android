"""Voice provider adapters with optional real backends and safe fallbacks."""
from pathlib import Path
import wave

class TextSpeechProvider:
    def speak(self, text: str):
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.say(text)
            engine.runAndWait()
            return {"spoken": True, "text": text, "provider": "pyttsx3"}
        except Exception as exc:
            return {"spoken": False, "text": text, "reason": f"TTS unavailable: {type(exc).__name__}"}

class SpeechTextProvider:
    def transcribe(self, audio):
        try:
            import speech_recognition as sr
        except ImportError as exc:
            raise RuntimeError("Install SpeechRecognition and a compatible audio backend for microphone STT") from exc
        recognizer = sr.Recognizer()
        if isinstance(audio, (str, Path)):
            with sr.AudioFile(str(audio)) as source:
                data = recognizer.record(source)
        else:
            data = audio
        # Google recognition is optional and requires network access.
        return recognizer.recognize_google(data)

class WavValidator:
    @staticmethod
    def validate(path):
        with wave.open(str(Path(path)), "rb") as w:
            return {"channels": w.getnchannels(), "rate": w.getframerate(), "frames": w.getnframes()}
