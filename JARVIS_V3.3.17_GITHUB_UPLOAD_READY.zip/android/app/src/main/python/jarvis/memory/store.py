import sqlite3
from datetime import datetime, timezone

class MemoryStore:
    def __init__(self, path: str):
        self.path = path
        self._shared = path == ":memory:"
        self._db = sqlite3.connect(path, timeout=10, check_same_thread=False) if self._shared else None
        self._init()

    def _connect(self):
        if self._shared:
            return self._db
        db = sqlite3.connect(self.path, timeout=10)
        db.execute("PRAGMA journal_mode=WAL")
        return db

    def _init(self):
        db = self._connect()
        db.execute("CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY, key TEXT UNIQUE, value TEXT NOT NULL, updated_at TEXT NOT NULL)")
        db.commit()
        if not self._shared: db.close()

    def set(self, key: str, value: str):
        now = datetime.now(timezone.utc).isoformat()
        db = self._connect()
        db.execute("INSERT INTO memories(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at", (key, str(value), now))
        db.commit()
        if not self._shared: db.close()

    def get(self, key: str):
        db = self._connect()
        row = db.execute("SELECT value FROM memories WHERE key=?", (key,)).fetchone()
        if not self._shared: db.close()
        return row[0] if row else None

    def delete(self, key: str):
        db = self._connect(); db.execute("DELETE FROM memories WHERE key=?", (key,)); db.commit()
        if not self._shared: db.close()

    def all(self):
        db = self._connect(); result = dict(db.execute("SELECT key,value FROM memories").fetchall())
        if not self._shared: db.close()
        return result

    def close(self):
        if self._db is not None:
            self._db.close(); self._db = None
