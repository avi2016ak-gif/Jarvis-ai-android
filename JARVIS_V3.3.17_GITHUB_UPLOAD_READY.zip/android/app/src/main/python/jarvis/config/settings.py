from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Settings:
    name: str = os.getenv("JARVIS_NAME", "JARVIS")
    db_path: str = os.getenv("JARVIS_DB", "jarvis_memory.db")
    owner_id: str = os.getenv("JARVIS_OWNER_ID", "owner")
    wake_word: str = os.getenv("JARVIS_WAKE_WORD", "hey jarvis")
