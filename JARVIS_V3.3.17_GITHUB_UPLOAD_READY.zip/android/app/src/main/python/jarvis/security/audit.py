from datetime import datetime, timezone
class AuditLog:
    def __init__(self): self.events=[]
    def record(self, actor, action, allowed):
        self.events.append({"time":datetime.now(timezone.utc).isoformat(),"actor":actor,"action":action,"allowed":bool(allowed)})
    def all(self): return list(self.events)
