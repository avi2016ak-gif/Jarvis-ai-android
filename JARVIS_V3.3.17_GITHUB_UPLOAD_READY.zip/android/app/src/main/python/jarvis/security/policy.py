class SecurityPolicy:
    def __init__(self, owner_id: str):
        self.owner_id = owner_id

    def authorize(self, actor_id: str, action: str) -> bool:
        # Conservative default: only the configured owner may execute actions.
        return actor_id == self.owner_id
