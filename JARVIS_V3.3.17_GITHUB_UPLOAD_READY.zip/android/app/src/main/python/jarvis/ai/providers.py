"""AI provider adapters. Network calls are opt-in via configuration."""
from dataclasses import dataclass
from typing import Any, Dict, Optional
import json, os, urllib.request

class AIProvider:
    name = "base"
    def generate(self, messages, **kwargs):
        raise NotImplementedError

class LocalEchoProvider(AIProvider):
    name = "local-echo"
    def generate(self, messages, **kwargs):
        user = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
        return {"text": f"JARVIS: {user}", "provider": self.name}

@dataclass
class OpenAICompatibleProvider(AIProvider):
    endpoint: str
    api_key: str
    model: str
    timeout: float = 30.0
    name: str = "openai-compatible"

    def generate(self, messages, **kwargs):
        if not self.endpoint or not self.api_key or not self.model:
            raise RuntimeError("AI provider is not configured")
        payload = {"model": self.model, "messages": messages}
        for key in ("temperature", "max_tokens", "response_format"):
            if key in kwargs and kwargs[key] is not None:
                payload[key] = kwargs[key]
        req = urllib.request.Request(
            self.endpoint.rstrip("/") + "/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as response:
            data = json.loads(response.read().decode())
        try:
            text = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError("AI provider returned an unexpected response") from exc
        return {"text": text, "provider": self.name, "raw": data}


def provider_from_env():
    endpoint = os.getenv("JARVIS_AI_ENDPOINT", "")
    key = os.getenv("JARVIS_AI_API_KEY", "")
    model = os.getenv("JARVIS_AI_MODEL", "")
    if endpoint and key and model:
        return OpenAICompatibleProvider(endpoint, key, model)
    return LocalEchoProvider()
