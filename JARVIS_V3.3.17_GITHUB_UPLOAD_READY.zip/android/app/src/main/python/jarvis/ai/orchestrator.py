"""AI conversation orchestration with legacy-provider compatibility and safe fallback."""
from .providers import provider_from_env, LocalEchoProvider

class AIOrchestrator:
    def __init__(self, registry=None):
        self.registry = registry
        self.primary = provider_from_env()
        self.fallback = LocalEchoProvider()
        # Keep the historical ProviderRegistry contract (handler receives text).
        # Only register a configured network provider; local echo remains the
        # final fallback so older user-registered providers retain priority.
        if registry is not None and self.primary.name != self.fallback.name:
            registry.register(
                self.primary.name,
                lambda text: self.primary.generate(self._messages(text)),
                priority=10,
            )

    @staticmethod
    def _messages(text, context=None):
        messages = [{"role": "system", "content": "You are JARVIS. Be concise, safe and truthful."}]
        if context:
            for turn in context[-10:]:
                messages.append({"role": turn["role"], "content": str(turn["text"])})
        messages.append({"role": "user", "content": text})
        return messages

    def chat(self, actor_id, text, context=None):
        if self.registry is not None:
            try:
                result = self.registry.call(text)
                if isinstance(result, dict):
                    return {"actor_id": actor_id, **result}
                return {"actor_id": actor_id, "text": str(result), "provider": "custom"}
            except RuntimeError:
                pass
        try:
            result = self.primary.generate(self._messages(text, context))
        except Exception:
            result = self.fallback.generate(self._messages(text, context))
        return {"actor_id": actor_id, **result}
