from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional

@dataclass
class Provider:
    name: str
    handler: Callable[..., Any]
    priority: int = 100
    enabled: bool = True

class ProviderRegistry:
    """Deterministic provider registry with graceful fallback selection."""
    def __init__(self): self._items: Dict[str, Provider] = {}
    def register(self, name, handler, priority=100, enabled=True):
        self._items[name] = Provider(name, handler, priority, enabled)
    def disable(self, name):
        if name in self._items: self._items[name].enabled = False
    def enable(self, name):
        if name in self._items: self._items[name].enabled = True
    def names(self): return [p.name for p in sorted(self._items.values(), key=lambda x: x.priority) if p.enabled]
    def call(self, *args, **kwargs):
        errors=[]
        for p in sorted(self._items.values(), key=lambda x: x.priority):
            if not p.enabled: continue
            try: return p.handler(*args, **kwargs)
            except Exception as exc: errors.append(f"{p.name}: {type(exc).__name__}")
        raise RuntimeError("No provider succeeded" + (" (" + "; ".join(errors) + ")" if errors else ""))
