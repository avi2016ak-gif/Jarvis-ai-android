"""Provider-neutral multimodal input gateway for text, images and screen frames."""
from dataclasses import dataclass
from typing import Any, Optional

@dataclass
class MultimodalInput:
    kind: str
    data: Any
    metadata: dict

class MultimodalGateway:
    def __init__(self, analyzer=None):
        self.analyzer = analyzer
    def inspect(self, actor_id: str, kind: str, data: Any, metadata: Optional[dict] = None):
        item = MultimodalInput(kind, data, metadata or {})
        if self.analyzer:
            return self.analyzer(actor_id, item)
        return {"kind": kind, "analyzed": False, "reason": "No vision analyzer configured", "metadata": item.metadata}
