"""Bounded per-owner session context for multi-turn command continuity."""
from dataclasses import dataclass, field
from collections import deque
from time import time

@dataclass
class Session:
    owner_id: str
    turns: deque = field(default_factory=lambda: deque(maxlen=20))
    created_at: float = field(default_factory=time)
    def add(self, role, text):
        self.turns.append({'role': role, 'text': str(text), 'ts': time()})
    def recent(self, limit=10):
        return list(self.turns)[-max(0, limit):]

class SessionManager:
    def __init__(self, max_sessions=32):
        self.max_sessions=max_sessions; self._sessions={}
    def get(self, owner_id):
        if owner_id not in self._sessions:
            if len(self._sessions)>=self.max_sessions:
                self._sessions.pop(next(iter(self._sessions)))
            self._sessions[owner_id]=Session(owner_id)
        return self._sessions[owner_id]
    def record(self, owner_id, role, text): self.get(owner_id).add(role,text)
    def context(self, owner_id, limit=10): return self.get(owner_id).recent(limit)
    def clear(self, owner_id): self._sessions.pop(owner_id,None)
