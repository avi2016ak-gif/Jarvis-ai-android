"""Bounded autonomous orchestration with explicit planning and safe action execution."""
from dataclasses import dataclass, field
from typing import List

@dataclass
class Step:
    action: str
    args: tuple = ()

@dataclass
class Plan:
    goal: str
    steps: List[Step] = field(default_factory=list)

class AutonomousOrchestrator:
    def __init__(self, jarvis): self.jarvis=jarvis
    def make_plan(self, text: str) -> Plan:
        parts=[p.strip() for p in (text or '').split(' then ') if p.strip()]
        steps=[]
        for p in parts or ['']:
            low=p.casefold()
            if low.startswith('remember ') and '=' in p[9:]:
                k,v=p[9:].split('=',1); steps.append(Step('remember',(k.strip(),v.strip())))
            elif low.startswith('research '): steps.append(Step('research',(p[9:].strip(),)))
            elif low.startswith('run '): steps.append(Step('run',(p[4:].strip(),)))
            elif low.startswith('recall '): steps.append(Step('recall',(p[7:].strip(),)))
            else: steps.append(Step('respond',(p,)))
        return Plan(text or '',steps)
    def execute(self, actor_id: str, text: str):
        plan=self.make_plan(text); results=[]
        for s in plan.steps:
            results.append(self._run(actor_id,s))
        return results[0] if len(results)==1 else results
    def _run(self, actor_id, s):
        if s.action=='remember': self.jarvis.remember(*s.args); return True
        if s.action=='recall': return self.jarvis.recall(*s.args)
        if s.action=='research': return self.jarvis.research.search(*s.args)
        if s.action=='run':
            name=s.args[0].casefold()
            if name=='health': return self.jarvis.health_status()
            if name=='status': return self.jarvis.status()
            raise PermissionError('Only registered safe autonomous actions are allowed')
        return self.jarvis.respond(actor_id,s.args[0])
