from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
@dataclass
class IntentResult:intent:str; result:object
class Orchestrator:
    def __init__(self,jarvis,max_workers=4):self.jarvis=jarvis;self.pool=ThreadPoolExecutor(max_workers=max_workers,thread_name_prefix='jarvis')
    def handle(self,actor_id,text):
        text=(text or '').strip();low=text.casefold()
        if not text:return IntentResult('empty',"I didn't receive a command.")
        if low in {'status','jarvis status'}:return IntentResult('status',self.jarvis.status())
        if low in {'health','jarvis health'}:return IntentResult('health',self.jarvis.health_status())
        if low.startswith('research '):return IntentResult('research',self.jarvis.research.search(text[9:].strip()))
        if low.startswith('remember ') and '=' in text:
            k,v=text[9:].split('=',1);self.jarvis.remember(k.strip(),v.strip());return IntentResult('remember',True)
        if low.startswith('recall '):return IntentResult('recall',self.jarvis.recall(text[7:].strip()))
        return IntentResult('chat',self.jarvis._respond_direct(actor_id,text))
    def submit(self,actor_id,text):return self.pool.submit(self.handle,actor_id,text)
    def shutdown(self):self.pool.shutdown(wait=True,cancel_futures=True)
