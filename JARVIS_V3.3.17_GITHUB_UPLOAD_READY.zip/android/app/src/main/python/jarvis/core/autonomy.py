"""Small, deterministic autonomous command planner/executor."""
from dataclasses import dataclass
import re

@dataclass
class ActionPlan:
    name: str
    args: tuple = ()
    requires_owner: bool = True

class AutonomousExecutor:
    def __init__(self, jarvis):
        self.jarvis = jarvis

    def plan(self, text: str):
        t = (text or '').strip()
        low = t.casefold()
        if low.startswith('remember ') and '=' in t[9:]:
            key, value = t[9:].split('=', 1)
            return ActionPlan('remember', (key.strip(), value.strip()))
        if low.startswith('recall '):
            return ActionPlan('recall', (t[7:].strip(),))
        if low.startswith('research '):
            return ActionPlan('research', (t[9:].strip(),))
        if low.startswith('run '):
            return ActionPlan('run', (t[4:].strip(),))
        return ActionPlan('respond', (t,))

    def execute(self, actor_id: str, text: str):
        plan = self.plan(text)
        if plan.name == 'remember':
            self.jarvis.remember(*plan.args); return True
        if plan.name == 'recall':
            return self.jarvis.recall(*plan.args)
        if plan.name == 'research':
            return self.jarvis.research.search(*plan.args)
        if plan.name == 'run':
            command = plan.args[0]
            # Never execute arbitrary Python/shell text. Only registered safe actions.
            if command.casefold() == 'health': return self.jarvis.health_status()
            if command.casefold() == 'status': return self.jarvis.status()
            raise PermissionError('Autonomous executor only permits registered safe actions')
        return self.jarvis.respond(actor_id, plan.args[0])
