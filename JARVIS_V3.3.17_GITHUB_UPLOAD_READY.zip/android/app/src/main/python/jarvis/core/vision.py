"""Provider-neutral vision analysis with safe metadata and hashing fallback."""
from dataclasses import dataclass
from hashlib import sha256
from typing import Any

@dataclass
class VisionResult:
    kind: str
    analyzed: bool
    provider: str
    result: Any = None
    sha256: str | None = None

class VisionProvider:
    def analyze(self, kind: str, data: Any, metadata: dict | None = None):
        raise NotImplementedError

class VisionGateway:
    def __init__(self, provider=None): self.provider = provider
    def inspect(self, kind: str, data: Any, metadata=None):
        metadata = metadata or {}
        digest = None
        if isinstance(data, (bytes, bytearray)):
            digest = sha256(data).hexdigest()
        if self.provider:
            try:
                result = self.provider.analyze(kind, data, metadata)
                return VisionResult(kind, True, type(self.provider).__name__, result, digest)
            except Exception as exc:
                return VisionResult(kind, False, type(self.provider).__name__, {"error": type(exc).__name__}, digest)
        return VisionResult(kind, False, "none", {"reason":"No vision provider configured","metadata":metadata}, digest)
