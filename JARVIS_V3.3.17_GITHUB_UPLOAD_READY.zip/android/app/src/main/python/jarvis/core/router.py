class CommandRouter:
    def __init__(self, jarvis): self.jarvis = jarvis
    def handle(self, actor_id, text):
        t = text.strip()
        low = t.lower()
        if low in {"status", "jarvis status"}:
            return self.jarvis.status()
        if low.startswith("remember ") and "=" in t[9:]:
            key, value = t[9:].split("=", 1); self.jarvis.remember(key.strip(), value.strip()); return "Remembered."
        if low.startswith("recall "):
            return self.jarvis.recall(t[7:].strip())
        return self.jarvis.respond(actor_id, t)
