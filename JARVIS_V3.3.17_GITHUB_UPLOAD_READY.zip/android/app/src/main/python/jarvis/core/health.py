from dataclasses import dataclass
from typing import Callable, Dict
@dataclass
class HealthResult:
    name:str; ok:bool; detail:str=''
class HealthMonitor:
    def __init__(self): self._checks:Dict[str,Callable[[],object]]={}
    def register(self,name,check): self._checks[name]=check
    def run(self):
        out=[]
        for name,check in self._checks.items():
            try:
                value=check(); out.append(HealthResult(name, value is not False, str(value)))
            except Exception as exc: out.append(HealthResult(name,False,f'{type(exc).__name__}: {exc}'))
        return out
