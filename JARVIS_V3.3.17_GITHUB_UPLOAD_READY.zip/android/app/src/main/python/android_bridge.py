"""Small Chaquopy bridge; Python core is the single source of behavior.

The Android UI authenticates locally before calling this module. This bridge
never accepts an actor/owner identifier from the UI: it always uses the
configured local owner identity.
"""
from pathlib import Path

_jarvis = None


def initialize(database_directory):
    """Initialize JARVIS using a database inside Android's private files dir."""
    global _jarvis
    directory = Path(str(database_directory)).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    database_path = directory / "jarvis_memory.db"

    # Import here so initialization is deterministic and does not rely on
    # environment variables having been set before module import.
    from jarvis.config.settings import Settings
    from jarvis.core.assistant import Jarvis

    if _jarvis is not None:
        _jarvis.shutdown()
    _jarvis = Jarvis(Settings(db_path=str(database_path), owner_id="owner"))
    return f"JARVIS V{_jarvis.VERSION} ready"


def _format_result(result):
    """Render core result objects as phone-friendly, plain text."""
    if hasattr(result, "sources") and hasattr(result, "question"):
        lines = [f"Research: {result.question}", "", str(result.answer or "No summary available.")]
        lines.append("\nSource-overlap check: " + ("PASS (rough lexical check only)" if result.verified else "NOT CONFIRMED"))
        lines.append("Note: overlap is not independent fact verification; review sources yourself.")
        for index, source in enumerate(result.sources[:5], 1):
            lines.extend([f"\n[{index}] {source.title}", source.url, (source.excerpt or "")[:500]])
        return "\n".join(lines)
    if isinstance(result, (dict, list, tuple)):
        import json
        return json.dumps(result, ensure_ascii=False, indent=2, default=str)
    return str(result)


def respond(message):
    """Respond as the locally authenticated app owner; no caller identity."""
    if _jarvis is None:
        raise RuntimeError("JARVIS has not been initialized")
    result = _jarvis.respond("owner", str(message))
    if hasattr(result, "result"):
        result = result.result
    return _format_result(result)


def shutdown():
    global _jarvis
    if _jarvis is not None:
        _jarvis.shutdown()
        _jarvis = None
