package com.jarvis.assistant

import android.content.Context

class LocalMemory(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_local_memory", Context.MODE_PRIVATE)
    fun remember(key: String, value: String) {
        // Local-only storage. Never uploads memory.
        prefs.edit().putString(key, value).apply()
    }
    fun recall(key: String): String? = prefs.getString(key, null)
    fun summary(): String {
        val entries = prefs.all.entries.sortedByDescending { it.key }.take(20)
        return if (entries.isEmpty()) "Memory is empty."
        else entries.joinToString("\n") { "${it.key}: ${it.value}" }
    }
    fun clear() { prefs.edit().clear().apply() }
}
