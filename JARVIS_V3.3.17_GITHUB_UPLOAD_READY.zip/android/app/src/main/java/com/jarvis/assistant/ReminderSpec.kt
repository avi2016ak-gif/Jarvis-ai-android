package com.jarvis.assistant

import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Parses an explicit device-local reminder time; never guesses a date/time. */
data class ParsedReminder(val dueAtMillis: Long, val message: String, val displayTime: String)

object ReminderSpec {
    private val formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm")

    fun parse(raw: String, nowMillis: Long, zone: ZoneId = ZoneId.systemDefault()): ParsedReminder? {
        val separator = raw.indexOf('|')
        if (separator < 0) return null
        val dateText = raw.substring(0, separator).trim()
        val message = raw.substring(separator + 1).trim()
        if (message.isBlank() || message.length > LocalTaskHandlers.MAX_CONTENT_LENGTH) return null
        val dueAt = try {
            LocalDateTime.parse(dateText, formatter).atZone(zone).toInstant().toEpochMilli()
        } catch (_: Exception) { return null }
        if (dueAt - nowMillis < 60_000L) return null
        return ParsedReminder(dueAt, message, dateText)
    }
}
