package com.jarvis.assistant

/**
 * Allow-listed task dispatch boundary. It never interprets free-form text as code.
 * A handler must be explicitly registered by the application before it can run.
 */
data class TaskExecutionResult(
    val successful: Boolean,
    val status: String,
    val detail: String
)

fun interface ApprovedTaskHandler {
    fun execute(action: ProtectedAction): TaskExecutionResult
}

class TaskHandlerRegistry(
    handlers: Map<String, ApprovedTaskHandler> = emptyMap()
) {
    private val registeredHandlers = handlers.toMap()

    fun registeredTypes(): Set<String> = registeredHandlers.keys.toSet()

    fun execute(action: ProtectedAction): TaskExecutionResult {
        if (action.type.isBlank()) {
            return TaskExecutionResult(false, STATUS_REJECTED, "Task type is empty; nothing was executed.")
        }
        val handler = registeredHandlers[action.type]
            ?: return TaskExecutionResult(
                false,
                STATUS_BLOCKED_NO_HANDLER,
                "No approved handler is registered for '${action.type}'; nothing was executed."
            )
        return try {
            handler.execute(action)
        } catch (error: Exception) {
            TaskExecutionResult(
                false,
                STATUS_HANDLER_ERROR,
                "Approved handler failed (${error.javaClass.simpleName}); task was not reported as successful."
            )
        }
    }

    companion object {
        const val STATUS_REJECTED = "REJECTED_INVALID_TASK_TYPE"
        const val STATUS_BLOCKED_NO_HANDLER = "BLOCKED_HANDLER_NOT_CONFIGURED"
        const val STATUS_HANDLER_ERROR = "FAILED_HANDLER_ERROR"
    }
}
