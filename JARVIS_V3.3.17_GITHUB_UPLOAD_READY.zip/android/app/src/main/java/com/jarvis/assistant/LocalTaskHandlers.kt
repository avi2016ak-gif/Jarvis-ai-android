package com.jarvis.assistant

/** Small storage boundary so task behavior can be tested without Android APIs. */
interface LocalTaskStore {
    fun append(kind: String, value: String, createdAtMillis: Long): String
    fun list(kind: String): List<String>
    fun update(id: String, kind: String, value: String, createdAtMillis: Long): Boolean = false
    fun remove(id: String, kind: String): Boolean = false
}

/** Only fixed, allow-listed local operations are implemented here. */
class LocalTaskHandlers(
    private val store: LocalTaskStore,
    private val nowMillis: () -> Long = { System.currentTimeMillis() }
) {
    fun asRegistry(): TaskHandlerRegistry = TaskHandlerRegistry(
        mapOf(
            TYPE_SAVE_NOTE to ApprovedTaskHandler { action -> save(TYPE_SAVE_NOTE, action.description) },
            TYPE_SAVE_REMINDER to ApprovedTaskHandler { action -> save(TYPE_SAVE_REMINDER, action.description) }
        )
    )

    private fun save(kind: String, rawValue: String): TaskExecutionResult {
        val value = rawValue.trim()
        if (value.isEmpty()) return TaskExecutionResult(false, STATUS_INVALID, "Empty content; nothing was saved.")
        if (value.length > MAX_CONTENT_LENGTH) return TaskExecutionResult(false, STATUS_INVALID, "Content is too long (max $MAX_CONTENT_LENGTH characters).")
        val id = store.append(kind, value, nowMillis())
        val label = if (kind == TYPE_SAVE_NOTE) "Note" else "Reminder"
        val detail = if (kind == TYPE_SAVE_NOTE) "Saved locally. No network access was used." else "Reminder saved locally; notification scheduling is handled by the Android task manager."
        return TaskExecutionResult(true, STATUS_SAVED, "$label $id: $detail")
    }

    companion object {
        const val TYPE_SAVE_NOTE = "SAVE_NOTE"
        const val TYPE_SAVE_REMINDER = "SAVE_REMINDER"
        const val TYPE_EDIT_REMINDER = "EDIT_REMINDER"
        const val TYPE_CANCEL_REMINDER = "CANCEL_REMINDER"
        const val STATUS_SAVED = "SAVED_LOCAL"
        const val STATUS_INVALID = "REJECTED_INVALID_CONTENT"
        const val MAX_CONTENT_LENGTH = 2000
    }
}
