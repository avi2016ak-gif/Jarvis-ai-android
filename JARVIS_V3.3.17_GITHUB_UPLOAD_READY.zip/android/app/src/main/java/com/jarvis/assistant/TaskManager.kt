package com.jarvis.assistant

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

class TaskManager(context: Context, private val memory: LocalMemory) {
    private val appContext = context.applicationContext
    private val workManager = WorkManager.getInstance(appContext)

    fun executeApproved(action: ProtectedAction): String {
        // This method is called only after the owner gate and Android device authentication.
        return when (action.type) {
            "BACKGROUND_TASK" -> schedulePersistentTask(action.description)
            LocalTaskHandlers.TYPE_SAVE_NOTE -> {
                val registry = LocalTaskHandlers(SharedPreferencesTaskStore(appContext)).asRegistry()
                val result = registry.execute(action)
                "${result.status}: ${result.detail}"
            }
            LocalTaskHandlers.TYPE_SAVE_REMINDER -> saveAndScheduleReminder(action)
            LocalTaskHandlers.TYPE_EDIT_REMINDER -> editReminder(action.description)
            LocalTaskHandlers.TYPE_CANCEL_REMINDER -> cancelReminder(action.description)
            "DELETE_DATA" -> "Deletion is disabled in this build. No data was deleted."
            "EXTERNAL_COMMUNICATION" -> "External communication is not configured. No message was sent."
            else -> "Unknown protected action; no operation performed."
        }
    }


    fun savedNotes(): String = formatRecords(
        SharedPreferencesTaskStore(appContext).list(LocalTaskHandlers.TYPE_SAVE_NOTE), "ಇನ್ನೂ ಯಾವುದೇ Notes ಉಳಿಸಿಲ್ಲ."
    )

    fun savedReminders(): String = formatRecords(
        SharedPreferencesTaskStore(appContext).list(LocalTaskHandlers.TYPE_SAVE_REMINDER), "ಇನ್ನೂ ಯಾವುದೇ Reminders ಉಳಿಸಿಲ್ಲ."
    )

    fun taskHistory(): String {
        val entries = SharedPreferencesTaskStore(appContext).history(50)
        return if (entries.isEmpty()) "ಇನ್ನೂ ಯಾವುದೇ Task History ಇಲ್ಲ." else entries.joinToString("\n")
    }

    private fun formatRecords(items: List<String>, empty: String): String =
        if (items.isEmpty()) empty else items.takeLast(20).joinToString("\n")

    /** Reminder format: yyyy-MM-dd HH:mm | reminder text (device local time). */
    private fun saveAndScheduleReminder(action: ProtectedAction): String {
        val parsed = ReminderSpec.parse(action.description, System.currentTimeMillis())
            ?: return "REJECTED_INVALID_REMINDER: Use yyyy-MM-dd HH:mm | reminder text and choose a time at least one minute in the future. Nothing was saved."
        val store = SharedPreferencesTaskStore(appContext)
        val id = store.append(LocalTaskHandlers.TYPE_SAVE_REMINDER, "${parsed.displayTime} | ${parsed.message}", System.currentTimeMillis())
        scheduleReminder(id, parsed.message, parsed.dueAtMillis - System.currentTimeMillis())
        return "SAVED_LOCAL: Reminder $id scheduled for ${parsed.displayTime} (device local time). Notification needs Android notification permission."
    }

    /** Approved edit format: reminder-id | yyyy-MM-dd HH:mm | new reminder text. */
    private fun editReminder(raw: String): String {
        val parts = raw.split('|', limit = 3).map { it.trim() }
        if (parts.size != 3 || !parts[0].matches(Regex("[A-Fa-f0-9-]{8,36}")))
            return "REJECTED_INVALID_EDIT: Use reminder-id | yyyy-MM-dd HH:mm | new reminder text."
        val id = parts[0]
        val parsed = ReminderSpec.parse("${parts[1]} | ${parts[2]}", System.currentTimeMillis())
            ?: return "REJECTED_INVALID_EDIT: Choose a valid future date/time and non-empty text. Nothing changed."
        val store = SharedPreferencesTaskStore(appContext)
        if (!store.update(id, LocalTaskHandlers.TYPE_SAVE_REMINDER, "${parsed.displayTime} | ${parsed.message}", System.currentTimeMillis()))
            return "NOT_FOUND: Reminder $id was not changed."
        workManager.cancelUniqueWork(reminderWorkName(id))
        scheduleReminder(id, parsed.message, parsed.dueAtMillis - System.currentTimeMillis())
        return "UPDATED: Reminder $id rescheduled for ${parsed.displayTime}."
    }

    /** Cancellation is also owner-approved; accepts only a stored reminder ID. */
    private fun cancelReminder(raw: String): String {
        val id = raw.trim()
        if (!id.matches(Regex("[A-Fa-f0-9-]{8,36}"))) return "REJECTED_INVALID_ID: Provide a reminder ID."
        val removed = SharedPreferencesTaskStore(appContext).remove(id, LocalTaskHandlers.TYPE_SAVE_REMINDER)
        if (!removed) return "NOT_FOUND: Reminder $id does not exist."
        workManager.cancelUniqueWork(reminderWorkName(id))
        return "CANCELLED: Reminder $id removed and its pending notification work cancelled."
    }

    private fun scheduleReminder(id: String, message: String, delayMillis: Long) {
        val request = OneTimeWorkRequestBuilder<JarvisReminderWorker>()
            .setInputData(workDataOf(JarvisReminderWorker.KEY_MESSAGE to message))
            .setInitialDelay(delayMillis.coerceAtLeast(1), TimeUnit.MILLISECONDS)
            .addTag(JarvisReminderWorker.TAG)
            .build()
        workManager.enqueueUniqueWork(reminderWorkName(id), ExistingWorkPolicy.REPLACE, request)
    }

    private fun reminderWorkName(id: String) = "jarvis_reminder_$id"

    fun latestTaskStatus(): String {
        val id = memory.recall("last_task_work_id")
            ?: return "ಯಾವುದೇ background task ಇಲ್ಲ."
        return try {
            val info = workManager.getWorkInfoById(java.util.UUID.fromString(id)).get()
            when {
                info == null -> "Task ಮಾಹಿತಿ ಲಭ್ಯವಿಲ್ಲ."
                info.state == WorkInfo.State.ENQUEUED -> "Task queued; Android executionಗಾಗಿ ಕಾಯುತ್ತಿದೆ."
                info.state == WorkInfo.State.RUNNING -> "Task running."
                info.state == WorkInfo.State.SUCCEEDED -> "Task completed."
                info.state == WorkInfo.State.FAILED -> "Task blocked/failed. ಈ build ನಲ್ಲಿ approved task handler ಇಲ್ಲ; ಯಾವುದೇ ಹೊರಗಿನ ಕೆಲಸ ನಡೆದಿಲ್ಲ."
                info.state == WorkInfo.State.CANCELLED -> "Task cancelled."
                else -> "Task: ${info.state.name}"
            }
        } catch (_: Exception) {
            "Task status ಓದಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ."
        }
    }

    private fun schedulePersistentTask(description: String): String {
        val request = OneTimeWorkRequestBuilder<JarvisBackgroundWorker>()
            .setInputData(workDataOf(JarvisBackgroundWorker.KEY_DESCRIPTION to description))
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag(JarvisBackgroundWorker.TAG)
            .build()
        workManager.enqueueUniqueWork(
            "jarvis_task_${request.id}", ExistingWorkPolicy.KEEP, request
        )
        memory.remember("last_task_request", description)
        memory.remember("last_task_work_id", request.id.toString())
        return "Owner verified. Background task queueಗೆ ಸೇರಿಸಲಾಗಿದೆ. ಆದರೆ ಈ build ನಲ್ಲಿ ಕಾರ್ಯ ನಿರ್ವಹಿಸುವ handler ಇನ್ನೂ ಇಲ್ಲ; status ಪರಿಶೀಲಿಸಿ. Task ID: ${request.id}"
    }
}
