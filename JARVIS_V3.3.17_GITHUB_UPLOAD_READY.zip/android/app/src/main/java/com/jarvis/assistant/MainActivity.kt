package com.jarvis.assistant

import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var pin: EditText
    private lateinit var send: Button
    private lateinit var mic: Button
    private lateinit var speak: Button
    private lateinit var language: Button
    private lateinit var approve: Button
    private lateinit var deny: Button
    private lateinit var notes: Button
    private lateinit var reminders: Button
    private lateinit var taskStatus: Button
    private lateinit var lockButton: Button
    private lateinit var localEngine: JarvisEngine
    private var speechLanguage = "kn-IN"
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var lastAnswer = ""
    /** Invalidates queued/in-flight UI responses whenever the owner locks the app. */
    private var requestGeneration = 0
    private var unlocked = false
    private val pinIterations = 210_000
    private val prefs by lazy { getSharedPreferences("jarvis_local_auth", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        localEngine = JarvisEngine(this)
        buildScreen()
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        initializeSpeech()
        if (prefs.getString("pin_hash", null) == null) {
            output.text = "ಮೊದಲ ಬಳಕೆ: ನಿಮ್ಮ ಖಾಸಗಿ PIN ರಚಿಸಿ. PIN ಅನ್ನು ಮರೆಯಬೇಡಿ."
            send.text = "PIN ಉಳಿಸಿ ಮತ್ತು ಪ್ರಾರಂಭಿಸಿ"
        } else {
            output.text = "JARVIS V3.3.17\nPIN ನಮೂದಿಸಿ."
            send.text = "Unlock"
        }
        send.setOnClickListener { authenticateOrSend() }
        mic.setOnClickListener { startListening() }
        speak.setOnClickListener { speakLastAnswer() }
        language.setOnClickListener { toggleSpeechLanguage() }
        approve.setOnClickListener { authenticateAndApprovePending() }
        deny.setOnClickListener { output.append("\n${localEngine.denyLastAction()}") }
        notes.setOnClickListener { output.append("\n\n${localEngine.savedNotes()}") }
        reminders.setOnClickListener { output.append("\n\n${localEngine.savedReminders()}") }
        taskStatus.setOnClickListener { output.append("\n\n${localEngine.latestTaskStatus()}") }
        lockButton.setOnClickListener { lockJarvis() }
    }

    private fun initializeSpeech() {
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = textToSpeech?.setLanguage(Locale("kn", "IN"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                if (!ttsReady) textToSpeech?.setLanguage(Locale.getDefault())
                runOnUiThread { speak.isEnabled = ttsReady && unlocked }
            }
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { runOnUiThread { mic.text = "ಕೇಳುತ್ತಿದ್ದೇನೆ…" } }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { runOnUiThread { mic.text = "🎙 ಮಾತಾಡಿ" } }
                    override fun onError(error: Int) {
                        runOnUiThread {
                            mic.text = "🎙 ಮಾತಾಡಿ"
                            Toast.makeText(this@MainActivity, "ಧ್ವನಿ ಗುರುತಿಸಲಾಗಲಿಲ್ಲ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        runOnUiThread {
                            mic.text = "🎙 ಮಾತಾಡಿ"
                            if (!spoken.isNullOrBlank()) { input.setText(spoken); sendMessage() }
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    private fun startListening() {
        if (!unlocked) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 410)
            return
        }
        val recognizer = speechRecognizer
        if (recognizer == null) {
            Toast.makeText(this, "ಈ Android ಸಾಧನದಲ್ಲಿ Speech Recognition ಲಭ್ಯವಿಲ್ಲ", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechLanguage)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, speechLanguage)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { recognizer.startListening(intent) }
        catch (e: Exception) { Toast.makeText(this, "Mic ಪ್ರಾರಂಭಿಸಲು ಆಗಲಿಲ್ಲ: ${e.message}", Toast.LENGTH_SHORT).show() }
    }

    private fun speakLastAnswer() {
        if (ttsReady && lastAnswer.isNotBlank()) {
            textToSpeech?.speak(lastAnswer, TextToSpeech.QUEUE_FLUSH, null, "jarvis-last-answer")
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
        }
        val heading = TextView(this).apply {
            text = "JARVIS  |  V3.3.17"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        pin = EditText(this).apply {
            hint = "Private PIN (6+ digits)"
            inputType = 18
        }
        output = TextView(this).apply { textSize = 16f; setPadding(4, 16, 4, 16) }
        val scroll = ScrollView(this).apply { addView(output) }
        input = EditText(this).apply {
            hint = "Ask JARVIS… (Kannada / English)"
            minLines = 2
        }
        send = Button(this).apply { text = "Unlock" }
        mic = Button(this).apply { text = "🎙 ಮಾತಾಡಿ"; isEnabled = false }
        speak = Button(this).apply { text = "🔊 ಉತ್ತರ ಕೇಳಿ"; isEnabled = false }
        language = Button(this).apply { text = "ಭಾಷೆ: ಕನ್ನಡ"; isEnabled = false }
        approve = Button(this).apply { text = "ಅನುಮೋದಿಸು"; isEnabled = false }
        deny = Button(this).apply { text = "ನಿರಾಕರಿಸು"; isEnabled = false }
        notes = Button(this).apply { text = "Notes"; isEnabled = false }
        reminders = Button(this).apply { text = "Reminders"; isEnabled = false }
        taskStatus = Button(this).apply { text = "Task Status"; isEnabled = false }
        lockButton = Button(this).apply { text = "🔒 Lock JARVIS"; isEnabled = false; visibility = View.GONE }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(mic, LinearLayout.LayoutParams(0, -2, 1f))
            addView(send, LinearLayout.LayoutParams(0, -2, 1f))
            addView(speak, LinearLayout.LayoutParams(0, -2, 1f))
            addView(language, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(heading)
        root.addView(pin)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(actions)
        val protectedActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(approve, LinearLayout.LayoutParams(0, -2, 1f))
            addView(deny, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val taskActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(notes, LinearLayout.LayoutParams(0, -2, 1f))
            addView(reminders, LinearLayout.LayoutParams(0, -2, 1f))
            addView(taskStatus, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(protectedActions)
        root.addView(taskActions)
        root.addView(lockButton)
        setContentView(root)
    }

    private fun authenticateOrSend() {
        val entered = pin.text.toString()
        val now = System.currentTimeMillis()
        val lockoutUntil = prefs.getLong("pin_lockout_until", 0L)
        if (now < lockoutUntil) {
            val seconds = ((lockoutUntil - now + 999) / 1000).toInt()
            Toast.makeText(this, "ತಾತ್ಕಾಲಿಕ ಲಾಕ್: ${seconds}s", Toast.LENGTH_SHORT).show()
            return
        }
        if (entered.length < 6 || entered.length > 12 || !entered.all { it.isDigit() }) {
            Toast.makeText(this, "6 ರಿಂದ 12 ಅಂಕಿಯ PIN ನಮೂದಿಸಿ", Toast.LENGTH_SHORT).show()
            return
        }
        val saved = prefs.getString("pin_hash", null)
        if (saved == null) {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val hash = derivePinHash(entered, salt)
            prefs.edit()
                .putString("pin_salt", salt.joinToString("") { "%02x".format(it) })
                .putString("pin_hash", hash)
                .apply()
            unlock()
        } else {
            val saltHex = prefs.getString("pin_salt", null)
            if (saltHex == null) {
                Toast.makeText(this, "ಹಳೆಯ PIN ಸಂಗ್ರಹ ಸುರಕ್ಷಿತವಲ್ಲ. App data reset ಮಾಡಿ ಹೊಸ PIN ರಚಿಸಿ.", Toast.LENGTH_LONG).show()
                return
            }
            val salt = hexToBytes(saltHex)
            val candidate = derivePinHash(entered, salt)
            val expected = saved.toByteArray(Charsets.UTF_8)
            val actual = candidate.toByteArray(Charsets.UTF_8)
            if (MessageDigest.isEqual(expected, actual)) {
                prefs.edit().putInt("pin_failed_attempts", 0).putLong("pin_lockout_until", 0L).apply()
                unlock()
            } else {
                val failedPins = prefs.getInt("pin_failed_attempts", 0) + 1
                if (failedPins >= 5) {
                    prefs.edit().putInt("pin_failed_attempts", 0).putLong("pin_lockout_until", now + 30_000L).apply()
                } else {
                    prefs.edit().putInt("pin_failed_attempts", failedPins).apply()
                }
                Toast.makeText(this, "PIN ತಪ್ಪಾಗಿದೆ", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun unlock() {
        unlocked = true
        pin.visibility = View.GONE
        send.text = "Send"
        mic.isEnabled = speechRecognizer != null
        speak.isEnabled = ttsReady
        language.isEnabled = true
        approve.isEnabled = true
        deny.isEnabled = true
        notes.isEnabled = true
        reminders.isEnabled = true
        taskStatus.isEnabled = true
        lockButton.isEnabled = true
        lockButton.visibility = View.VISIBLE
        input.isEnabled = true
        output.text = "JARVIS V3.3.17 ಸಿದ್ಧವಾಗಿದೆ.\nಮುಖ್ಯ commands: status, health, remember key=value, recall key"
        send.setOnClickListener { sendMessage() }
        worker.execute {
            try {
                val bridge = Python.getInstance().getModule("android_bridge")
                val message = bridge.callAttr("initialize", filesDir.absolutePath).toString()
                runOnUiThread { output.append("\n$message") }
            } catch (e: Exception) {
                runOnUiThread { output.append("\nInitialization error: ${e.message}") }
            }
        }
    }

    /** Immediately returns the UI to owner-PIN lock without destroying local data. */
    private fun lockJarvis() {
        if (!unlocked) return
        unlocked = false
        requestGeneration += 1 // discard any late AI response from the previous unlocked session
        try { speechRecognizer?.cancel() } catch (_: Exception) { }
        try { textToSpeech?.stop() } catch (_: Exception) { }
        lastAnswer = ""
        input.setText("")
        input.isEnabled = false
        pin.setText("")
        pin.visibility = View.VISIBLE
        mic.isEnabled = false
        speak.isEnabled = false
        language.isEnabled = false
        approve.isEnabled = false
        deny.isEnabled = false
        notes.isEnabled = false
        reminders.isEnabled = false
        taskStatus.isEnabled = false
        lockButton.isEnabled = false
        lockButton.visibility = View.GONE
        send.text = "Unlock"
        send.setOnClickListener { authenticateOrSend() }
        output.text = "JARVIS V3.3.17 ಲಾಕ್ ಮಾಡಲಾಗಿದೆ. ಮುಂದುವರಿಸಲು Owner PIN ನಮೂದಿಸಿ."
    }

    private fun authenticateAndApprovePending() {
        val pending = localEngine.pendingActionDescription()
        if (pending == null) {
            output.append("\nಯಾವುದೇ pending approval ಇಲ್ಲ.")
            return
        }
        val now = System.currentTimeMillis()
        val lockoutUntil = prefs.getLong("pin_lockout_until", 0L)
        if (now < lockoutUntil) {
            val seconds = ((lockoutUntil - now + 999) / 1000).toInt()
            Toast.makeText(this, "ತಾತ್ಕಾಲಿಕ PIN ಲಾಕ್: ${seconds}s", Toast.LENGTH_SHORT).show()
            return
        }
        if (localEngine.pendingActionType() == LocalTaskHandlers.TYPE_SAVE_REMINDER &&
            android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 411)
            Toast.makeText(this, "Notification permission ಕೊಟ್ಟ ನಂತರ ಮತ್ತೆ ಅನುಮೋದಿಸು ಒತ್ತಿ.", Toast.LENGTH_LONG).show()
            return
        }
        val pinEntry = EditText(this).apply {
            hint = "Owner PIN"
            inputType = 18
        }
        AlertDialog.Builder(this)
            .setTitle("Owner approval")
            .setMessage("ಈ ಕಾರ್ಯಕ್ಕೆ ಅನುಮತಿ ನೀಡುತ್ತೀರಾ?\n$pending")
            .setView(pinEntry)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Approve") { _, _ ->
                val entered = pinEntry.text.toString()
                val saltHex = prefs.getString("pin_salt", null)
                val savedHash = prefs.getString("pin_hash", null)
                val valid = try {
                    entered.length in 6..12 && entered.all { it.isDigit() } &&
                        saltHex != null && savedHash != null &&
                        MessageDigest.isEqual(
                            savedHash.toByteArray(Charsets.UTF_8),
                            derivePinHash(entered, hexToBytes(saltHex)).toByteArray(Charsets.UTF_8)
                        )
                } catch (_: Exception) { false }
                if (!valid) {
                    val failures = prefs.getInt("pin_failed_attempts", 0) + 1
                    if (failures >= 5) {
                        prefs.edit().putInt("pin_failed_attempts", 0)
                            .putLong("pin_lockout_until", System.currentTimeMillis() + 30_000L).apply()
                        output.append("\nಐದು ತಪ್ಪು ಪ್ರಯತ್ನಗಳು. 30 ಸೆಕೆಂಡ್ ಲಾಕ್; ಕಾರ್ಯ ನಡೆಸಿಲ್ಲ.")
                    } else {
                        prefs.edit().putInt("pin_failed_attempts", failures).apply()
                        output.append("\nOwner PIN ತಪ್ಪಾಗಿದೆ ($failures/5). ಕಾರ್ಯ ನಡೆಸಿಲ್ಲ.")
                    }
                    return@setPositiveButton
                }
                prefs.edit().putInt("pin_failed_attempts", 0).putLong("pin_lockout_until", 0L).apply()
                val result = localEngine.approveLastAction()
                output.append("\n\nJARVIS: $result")
                lastAnswer = result
                if (ttsReady && result.isNotBlank()) textToSpeech?.speak(result, TextToSpeech.QUEUE_FLUSH, null, "jarvis-approved-result")
            }
            .show()
    }

    private fun sendMessage() {
        if (!unlocked) return
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        input.setText("")
        val localReply = localEngine.processLocalCommand(message)
        if (localReply != null) {
            output.append("\n\nನೀವು: $message\nJARVIS: ${localReply.message}")
            lastAnswer = localReply.message
            if (localReply.speak && ttsReady) textToSpeech?.speak(lastAnswer, TextToSpeech.QUEUE_FLUSH, null, "jarvis-local-reply")
            return
        }
        output.append("\n\nನೀವು: $message\nJARVIS: ...")
        val generation = requestGeneration
        worker.execute {
            try {
                val answer = Python.getInstance().getModule("android_bridge")
                    .callAttr("respond", message).toString()
                runOnUiThread {
                    // A response may finish after the owner locks or starts a new session.
                    if (!unlocked || generation != requestGeneration) return@runOnUiThread
                    lastAnswer = answer
                    val old = output.text.toString().removeSuffix("...")
                    output.text = "$old$answer"
                    speak.isEnabled = ttsReady && answer.isNotBlank()
                }
            } catch (e: Exception) {
                runOnUiThread { output.append("\nದೋಷ: ${e.message}") }
            }
        }
    }

    private fun toggleSpeechLanguage() {
        speechLanguage = if (speechLanguage == "kn-IN") "en-IN" else "kn-IN"
        language.text = if (speechLanguage == "kn-IN") "ಭಾಷೆ: ಕನ್ನಡ" else "Language: English"
        val locale = if (speechLanguage == "kn-IN") Locale("kn", "IN") else Locale("en", "IN")
        val result = textToSpeech?.setLanguage(locale)
        ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        speak.isEnabled = unlocked && ttsReady
    }

    private fun derivePinHash(value: String, salt: ByteArray): String {
        val spec = PBEKeySpec(value.toCharArray(), salt, pinIterations, 256)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
            bytes.joinToString("") { "%02x".format(it) }
        } finally {
            spec.clearPassword()
        }
    }

    private fun hexToBytes(value: String): ByteArray {
        require(value.length % 2 == 0)
        return ByteArray(value.length / 2) { i ->
            value.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 410 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else if (requestCode == 410) Toast.makeText(this, "ಧ್ವನಿ input ಗೆ microphone permission ಅಗತ್ಯ", Toast.LENGTH_LONG).show()
        else if (requestCode == 411 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Notification permission ಸಿಕ್ಕಿದೆ. ಈಗ ಅನುಮೋದಿಸು ಒತ್ತಿ.", Toast.LENGTH_LONG).show()
        else if (requestCode == 411)
            Toast.makeText(this, "Notification permission ಇಲ್ಲ; ರಿಮೈಂಡರ್ notification ತಲುಪದು.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        try { speechRecognizer?.destroy() } catch (_: Exception) { }
        speechRecognizer = null
        try { textToSpeech?.stop(); textToSpeech?.shutdown() } catch (_: Exception) { }
        textToSpeech = null
        if (isFinishing && Python.isStarted()) {
            try {
                worker.execute {
                    try { Python.getInstance().getModule("android_bridge").callAttr("shutdown") }
                    catch (_: Exception) { }
                }
            } catch (_: Exception) { }
        }
        worker.shutdown()
        super.onDestroy()
    }
}
