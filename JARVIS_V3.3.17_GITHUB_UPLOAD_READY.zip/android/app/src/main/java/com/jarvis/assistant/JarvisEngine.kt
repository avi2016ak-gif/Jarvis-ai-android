package com.jarvis.assistant

import android.content.Context

/** Local task intent adapter. It never executes an action before owner approval. */
data class JarvisReply(val message: String, val speak: Boolean = true)

class JarvisEngine(context: Context) {
    private val memory = LocalMemory(context)
    private val gate = OwnerPermissionGate()
    private val tasks = TaskManager(context, memory)

    /** Returns null when the message belongs to the existing Python core. */
    fun processLocalCommand(raw: String): JarvisReply? {
        val text = raw.trim()
        if (text.isEmpty()) return null
        val lower = text.lowercase()
        return when {
            lower.startsWith("note:") || lower.startsWith("ನೋಟ್:") ->
                JarvisReply(gate.request(LocalTaskHandlers.TYPE_SAVE_NOTE, text.substringAfter(':').trim()))
            lower.startsWith("remind:") || lower.startsWith("ರಿಮೈಂಡರ್:") ->
                JarvisReply(gate.request(LocalTaskHandlers.TYPE_SAVE_REMINDER, text.substringAfter(':').trim()))
            lower.startsWith("edit reminder:") || lower.startsWith("ರಿಮೈಂಡರ್ ಬದಲಾಯಿಸು:") ->
                JarvisReply(gate.request(LocalTaskHandlers.TYPE_EDIT_REMINDER, text.substringAfter(':').trim()))
            lower.startsWith("cancel reminder:") || lower.startsWith("ರಿಮೈಂಡರ್ ರದ್ದು:") ->
                JarvisReply(gate.request(LocalTaskHandlers.TYPE_CANCEL_REMINDER, text.substringAfter(':').trim()))
            lower == "show notes" || lower == "notes ತೋರಿಸು" || lower == "ನೋಟ್ಸ್ ತೋರಿಸು" ->
                JarvisReply(tasks.savedNotes(), speak = false)
            lower == "show reminders" || lower == "reminders ತೋರಿಸು" || lower == "ರಿಮೈಂಡರ್ ತೋರಿಸು" ->
                JarvisReply(tasks.savedReminders(), speak = false)
            lower == "task history" || lower == "ಕೆಲಸದ ಇತಿಹಾಸ" || lower == "ಹಿಸ್ಟರಿ ತೋರಿಸು" ->
                JarvisReply(tasks.taskHistory(), speak = false)
            lower == "task status" || lower == "background task status" ->
                JarvisReply(tasks.latestTaskStatus(), speak = false)
            lower.startsWith("background:") || lower.startsWith("ಹಿನ್ನೆಲೆ:") ->
                JarvisReply(gate.request("BACKGROUND_TASK", text.substringAfter(':').trim()))
            else -> null
        }
    }

    fun pendingActionDescription(): String? = gate.pendingDescription()
    fun pendingActionType(): String? = gate.pendingType()
    fun approveLastAction(): String {
        val action = gate.approve()
        return if (action == null) "ಅನುಮೋದಿಸಲು pending action ಇಲ್ಲ." else tasks.executeApproved(action)
    }
    fun denyLastAction(): String = if (gate.deny()) "Action ನಿರಾಕರಿಸಲಾಗಿದೆ." else "Pending action ಇಲ್ಲ."
    fun savedNotes(): String = tasks.savedNotes()
    fun savedReminders(): String = tasks.savedReminders()
    fun taskHistory(): String = tasks.taskHistory()
    fun latestTaskStatus(): String = tasks.latestTaskStatus()
}
