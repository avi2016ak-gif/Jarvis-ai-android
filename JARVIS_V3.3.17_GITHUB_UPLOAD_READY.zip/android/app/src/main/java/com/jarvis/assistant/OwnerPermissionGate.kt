package com.jarvis.assistant

/**
 * Fail-closed, single-pending-action approval gate.
 * A second request cannot silently replace the action shown to the owner.
 * Pending approvals expire after five minutes and are cleared on app restart
 * because this gate is intentionally memory-only.
 */
data class ProtectedAction(
    val type: String,
    val description: String,
    val requestedAtMillis: Long
)

class OwnerPermissionGate(
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
    private val expiryMillis: Long = 5 * 60 * 1000L
) {
    private var pending: ProtectedAction? = null

    @Synchronized
    fun request(type: String, description: String): String {
        expireIfNeeded()
        val current = pending
        if (current != null) {
            return "APPROVAL ALREADY PENDING: ${current.description}. Deny or approve that request first; the new request was NOT queued."
        }
        pending = ProtectedAction(type, description, nowMillis())
        return "OWNER APPROVAL REQUIRED: $description. No action has been performed. Authenticate and approve, or deny."
    }

    @Synchronized
    fun pendingDescription(): String? {
        expireIfNeeded()
        return pending?.description
    }

    @Synchronized
    fun pendingType(): String? {
        expireIfNeeded()
        return pending?.type
    }

    @Synchronized
    fun approve(): ProtectedAction? {
        expireIfNeeded()
        val result = pending
        pending = null
        return result
    }

    @Synchronized
    fun deny(): Boolean {
        expireIfNeeded()
        val existed = pending != null
        pending = null
        return existed
    }

    private fun expireIfNeeded() {
        val current = pending ?: return
        if (nowMillis() - current.requestedAtMillis > expiryMillis) pending = null
    }
}
