package com.jarvis.assistant

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Durable WorkManager entry point. This build deliberately does not execute
 * arbitrary user instructions. Until a reviewed handler is registered, the
 * worker records a blocked state and fails visibly rather than claiming success.
 */
class JarvisBackgroundWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val description = inputData.getString(KEY_DESCRIPTION)
            ?: return Result.failure()
        val prefs = applicationContext.getSharedPreferences("jarvis_local_memory", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("background_task_last_status", STATUS_BLOCKED)
            .putString("background_task_last_description", description)
            .putLong("background_task_last_updated", System.currentTimeMillis())
            .putString("background_task_last_detail", "No approved task handler is installed; no operation was performed.")
            .apply()
        return Result.failure()
    }

    companion object {
        const val KEY_DESCRIPTION = "task_description"
        const val TAG = "jarvis_background_task"
        const val STATUS_BLOCKED = "BLOCKED_HANDLER_NOT_CONFIGURED"
    }
}
