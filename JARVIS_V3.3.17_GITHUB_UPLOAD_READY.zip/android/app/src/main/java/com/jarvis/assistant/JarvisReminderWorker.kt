package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Posts a local reminder notification; it does not access the network. */
class JarvisReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val message = inputData.getString(KEY_MESSAGE)?.takeIf { it.isNotBlank() } ?: return Result.failure()
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "JARVIS Reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
        return try {
            val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("JARVIS Reminder")
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(applicationContext).notify(message.hashCode(), notification)
            Result.success()
        } catch (_: SecurityException) {
            Result.failure()
        }
    }

    companion object {
        const val KEY_MESSAGE = "reminder_message"
        const val TAG = "jarvis_reminder"
        private const val CHANNEL_ID = "jarvis_reminders"
    }
}
