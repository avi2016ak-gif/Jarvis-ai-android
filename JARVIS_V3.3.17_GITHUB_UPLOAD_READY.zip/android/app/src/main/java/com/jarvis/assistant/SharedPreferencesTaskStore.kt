package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Local-only task records in app-private SharedPreferences. */
class SharedPreferencesTaskStore(context: Context) : LocalTaskStore {
    private val prefs = context.applicationContext.getSharedPreferences("jarvis_task_records", Context.MODE_PRIVATE)

    @Synchronized
    override fun append(kind: String, value: String, createdAtMillis: Long): String {
        val id = UUID.randomUUID().toString().take(8)
        val current = readArray()
        current.put(JSONObject().put("id", id).put("kind", kind).put("value", value).put("createdAt", createdAtMillis))
        // Keep the newest 100 records to bound local storage.
        val bounded = JSONArray()
        val start = (current.length() - MAX_RECORDS).coerceAtLeast(0)
        for (index in start until current.length()) bounded.put(current.getJSONObject(index))
        check(prefs.edit().putString(KEY_RECORDS, bounded.toString()).commit()) { "Could not persist local task" }
        return id
    }

    @Synchronized
    override fun list(kind: String): List<String> = readRecords(kind)


    @Synchronized
    override fun update(id: String, kind: String, value: String, createdAtMillis: Long): Boolean {
        val current = readArray()
        var found = false
        for (index in 0 until current.length()) {
            val item = current.getJSONObject(index)
            if (item.optString("id") == id && item.optString("kind") == kind) {
                item.put("value", value).put("createdAt", createdAtMillis)
                found = true
                break
            }
        }
        return found && prefs.edit().putString(KEY_RECORDS, current.toString()).commit()
    }

    @Synchronized
    override fun remove(id: String, kind: String): Boolean {
        val current = readArray()
        val kept = JSONArray()
        var found = false
        for (index in 0 until current.length()) {
            val item = current.getJSONObject(index)
            if (item.optString("id") == id && item.optString("kind") == kind) found = true
            else kept.put(item)
        }
        return found && prefs.edit().putString(KEY_RECORDS, kept.toString()).commit()
    }

    @Synchronized
    fun history(limit: Int = 50): List<String> {
        val array = readArray()
        val start = (array.length() - limit.coerceIn(1, MAX_RECORDS)).coerceAtLeast(0)
        val result = mutableListOf<String>()
        for (index in start until array.length()) {
            val item = array.getJSONObject(index)
            val kind = item.optString("kind")
            val label = if (kind == LocalTaskHandlers.TYPE_SAVE_NOTE) "NOTE" else if (kind == LocalTaskHandlers.TYPE_SAVE_REMINDER) "REMINDER" else kind
            val date = java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.optLong("createdAt")))
            result += "$date [$label ${item.optString("id")}] ${item.optString("value")}" 
        }
        return result
    }

    private fun readRecords(kind: String): List<String> {
        val result = mutableListOf<String>()
        val array = readArray()
        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            if (item.optString("kind") == kind) result += "${item.optString("id")}: ${item.optString("value")}" 
        }
        return result
    }

    private fun readArray(): JSONArray = try {
        JSONArray(prefs.getString(KEY_RECORDS, "[]"))
    } catch (_: Exception) {
        JSONArray()
    }

    companion object {
        private const val KEY_RECORDS = "records"
        private const val MAX_RECORDS = 100
    }
}
