# Build JARVIS APK without installing Android Studio on your phone

This repository includes a GitHub Actions workflow at `.github/workflows/android-build.yml`.
It runs the source checks and Kotlin/Python tests, builds `assembleDebug`, and publishes
`app-debug.apk` plus a SHA-256 checksum and build metadata as downloadable workflow artifacts.

## One-time setup (phone browser or GitHub app)

1. Create a private GitHub repository.
2. Upload the contents of this ZIP to the repository (keep the `.github` folder; enable
   display of hidden files if your upload tool hides it).
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Select **JARVIS Android build** and tap **Run workflow**. A push to the `android/`,
   `scripts/`, or workflow paths also starts it automatically.
5. When the run is green, open that run, scroll to **Artifacts**, and download
   `jarvis-v3.3.17-debug-apk` and verify the included checksum before installation. Extract it and install `app-debug.apk` on the Android phone.

## Important

- This is a debug APK for installation/testing, not a signed production release.
- Keep the repository private. Do not upload API keys, passwords, personal databases,
  or real user data.
- GitHub Actions availability and usage limits depend on the GitHub account/repository.
- A green workflow is the first real Android Gradle build validation; the offline checks
  in this source ZIP do not claim to be an APK build.
- If the workflow fails, open the failed step's log and use that error to fix the source.


## Phone upload notes
- Extract the downloaded source ZIP with your phone Files app. The ZIP top level is the repository root and includes the hidden `.github` folder.
- Create a **private** repository named `jarvis-android`, then upload the extracted files using GitHub web upload. If hidden files are not shown, add `.github/workflows/android-build.yml` using GitHub file creation.
- Confirm `android/`, `scripts/`, `.github/`, `README.md`, and `BUILD_ON_GITHUB.md` are directly at the repository root, not inside another folder.
- Run the workflow manually in Actions. Download its artifact ZIP, extract, and install the debug APK; Android may ask to allow installs from that app.
