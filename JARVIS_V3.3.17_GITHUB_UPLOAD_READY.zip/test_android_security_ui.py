from pathlib import Path

ROOT = Path(__file__).parent
KOTLIN = (ROOT / "android/app/src/main/java/com/jarvis/assistant/MainActivity.kt").read_text()
GRADLE = (ROOT / "android/app/build.gradle").read_text()
MAIN = KOTLIN


def test_lockout_persists_in_private_preferences():
    assert 'getLong("pin_lockout_until", 0L)' in KOTLIN
    assert 'putLong("pin_lockout_until", now + 30_000L)' in KOTLIN
    assert 'getInt("pin_failed_attempts", 0)' in KOTLIN
    assert 'putInt("pin_failed_attempts", 0)' in KOTLIN


def test_kannada_english_voice_switch_is_wired():
    assert 'speechLanguage = "kn-IN"' in KOTLIN
    assert 'speechLanguage = if (speechLanguage == "kn-IN") "en-IN" else "kn-IN"' in KOTLIN
    assert 'EXTRA_LANGUAGE, speechLanguage' in KOTLIN
    assert 'setLanguage(locale)' in KOTLIN
    assert 'language.setOnClickListener { toggleSpeechLanguage() }' in KOTLIN


def test_android_version_incremented():
    assert "versionCode 49" in GRADLE
    assert "versionName '3.3.17'" in GRADLE
    assert MAIN.count("V3.3.17") >= 3
    assert "V3.3.2" not in MAIN


def test_owner_approval_and_task_modules_are_wired():
    base = ROOT / "android/app/src/main/java/com/jarvis/assistant"
    main = (base / "MainActivity.kt").read_text()
    assert "authenticateAndApprovePending()" in main
    assert "derivePinHash(entered, hexToBytes(saltHex))" in main
    assert "localEngine.processLocalCommand(message)" in main
    assert (base / "TaskManager.kt").exists()
    assert (base / "JarvisReminderWorker.kt").exists()
    assert 'POST_NOTIFICATIONS' in (ROOT / "android/app/src/main/AndroidManifest.xml").read_text()
    assert "coreLibraryDesugaringEnabled true" in (ROOT / "android/app/build.gradle").read_text()


def test_task_registry_fails_closed_for_unknown_actions():
    registry = (ROOT / "android/app/src/main/java/com/jarvis/assistant/TaskHandlerRegistry.kt").read_text()
    assert "BLOCKED_HANDLER_NOT_CONFIGURED" in registry
    assert "registeredHandlers[action.type]" in registry
    assert "No approved handler is registered" in registry


def test_manual_lock_clears_transient_content_and_relocks():
    assert 'private fun lockJarvis()' in KOTLIN
    assert 'lastAnswer = ""' in KOTLIN
    assert 'input.setText("")' in KOTLIN
    assert 'speechRecognizer?.cancel()' in KOTLIN
    assert 'pin.visibility = View.VISIBLE' in KOTLIN
    assert 'lockButton.setOnClickListener { lockJarvis() }' in KOTLIN
    assert 'lockButton.visibility = View.GONE' in KOTLIN
    assert 'send.setOnClickListener { authenticateOrSend() }' in KOTLIN


def test_lock_invalidates_late_ai_responses():
    assert "private var requestGeneration = 0" in KOTLIN
    assert "requestGeneration += 1" in KOTLIN
    assert "val generation = requestGeneration" in KOTLIN
    assert "if (!unlocked || generation != requestGeneration) return@runOnUiThread" in KOTLIN


def test_preflight_checks_package_hygiene():
    script = (ROOT / "scripts/android_preflight.py").read_text()
    assert "Source packager excludes runtime database files" in script
    assert "Python bytecode/cache excluded from source tree" in script


def test_source_packaging_excludes_runtime_artifacts():
    from scripts.package_android_source import excluded, ROOT
    assert excluded(ROOT / "jarvis_memory.db")
    assert excluded(ROOT / "__pycache__" / "sample.pyc")
    assert excluded(ROOT / "android" / "local.properties")
    assert not excluded(ROOT / "android" / "app" / "build.gradle")
