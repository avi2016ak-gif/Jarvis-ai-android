import os, tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings

fd, path = tempfile.mkstemp(); os.close(fd)
try:
    j=Jarvis(Settings(db_path=path, owner_id="me"))
    j.remember("language", "Kannada + English")
    assert j.recall("language") == "Kannada + English"
    assert j.execute("me", "math", lambda: 2+3) == 5
    assert j.tasks.safe_run("me", "fail", lambda: 1/0).ok is False
    try: j.execute("bad", "danger", lambda: 1)
    except PermissionError: pass
    else: raise AssertionError("security failed")
    f=j.tasks.submit("me", "async", lambda: "done"); assert f.result(timeout=2)=="done"
    print("INTEGRATION TEST: PASS")
finally: os.remove(path)
