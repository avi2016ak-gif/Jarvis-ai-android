from jarvis.core.assistant import Jarvis

if __name__ == "__main__":
    jarvis = Jarvis()
    print("JARVIS online")
    print(jarvis.status())
