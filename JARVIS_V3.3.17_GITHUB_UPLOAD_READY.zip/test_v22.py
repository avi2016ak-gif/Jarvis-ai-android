from jarvis.core.assistant import Jarvis
from jarvis.research.models import ResearchResult
j=Jarvis()
assert tuple(map(int, j.status()["version"].split("."))) >= (2, 8)
assert j.wakeword.detect("Hey Jarvis status")
assert j.wakeword.strip_wake_word("Hey Jarvis status") == "status"
j.remember("x","123"); assert j.recall("x")=="123"
assert j.execute("owner","test",lambda: 7)==7
try: j.execute("intruder","test",lambda: 7); raise AssertionError
except PermissionError: pass
j.shutdown(); print("JARVIS V2.2 TEST: PASS")
