# JARVIS V3.3.9

- Updated Android app version to 3.3.9 (versionCode 41).
- Cloud build now creates a SHA-256 checksum for the debug APK.
- Cloud build publishes build metadata (version, commit, UTC build time, APK checksum) beside the APK.
- Phone instructions explain checksum verification before installation.
- Owner Permission Gate and fail-closed unknown-task handling remain unchanged.
- Cloud workflow has not yet been run remotely; no APK build success is claimed.
