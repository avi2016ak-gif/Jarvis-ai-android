import os,tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings
from jarvis.core.vision import VisionGateway
from jarvis.research.models import ResearchSource
from jarvis.research.verify import verify_sources

fd,p=tempfile.mkstemp(); os.close(fd)
j=Jarvis(Settings(db_path=p, owner_id='owner'))
try:
    assert tuple(map(int, j.VERSION.split('.'))) >= (2, 8)
    assert tuple(map(int, j.status()['version'].split('.'))) >= (2, 8)
    media=j.inspect_media('owner','image',b'abc',{'source':'camera'})
    assert media['analyzed'] is False and len(media['sha256'])==64
    try: j.inspect_media('bad','image',b'abc'); raise AssertionError('security failed')
    except PermissionError: pass
    a=ResearchSource('a','https://a','the government announced a major policy change for public services today')
    b=ResearchSource('b','https://b','official sources reported a major policy change for public services today')
    assert verify_sources([a,b])['verified'] is True
    print('JARVIS V2.8 TEST: PASS')
finally:
    j.shutdown(); os.remove(p)
