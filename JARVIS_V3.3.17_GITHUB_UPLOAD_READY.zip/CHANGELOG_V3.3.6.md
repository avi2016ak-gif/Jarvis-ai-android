# JARVIS V3.3.6 — Kotlin safety-core compilation

- Bumped Android `versionName` to `3.3.6` and `versionCode` to `38`.
- Added `scripts/kotlin_core_smoke.sh`: compiles the real Kotlin owner-approval gate, task registry, and fixed local task handlers with `kotlinc`, then executes 10 assertions covering approval queue protection, approve/deny/expiry, unknown-task blocking, allow-listed note saving, and empty-content rejection.
- Added this Kotlin compile/runtime check to `scripts/run_tests.sh`.
- Build diagnostics now report standalone Kotlin compiler availability separately.
- This is not a full Android Gradle build: Android SDK and Gradle wrapper/executable are still missing, so APK generation and device testing remain pending.
