import os,tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings
fd,p=tempfile.mkstemp(); os.close(fd)
j=Jarvis(Settings(db_path=p,owner_id='owner'))
try:
    assert j.VERSION == '3.1'
    r=j.respond('owner','hello Jarvis')
    assert r.intent == 'chat'
    assert 'hello Jarvis' in str(r.result)
    assert j.status()['ai_provider'] == 'local-echo'
    assert j.status()['compatibility'] == 'v2.1-v3.1'
    print('JARVIS V3.1 TEST: PASS')
finally:
    j.shutdown(); os.remove(p)
