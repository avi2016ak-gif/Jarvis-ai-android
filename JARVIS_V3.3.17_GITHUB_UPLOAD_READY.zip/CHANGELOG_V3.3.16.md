# JARVIS V3.3.16

- Fix: owner lock now invalidates queued/in-flight AI response UI callbacks, preventing stale responses from appearing after relock.
- Android version metadata updated to 3.3.16 (versionCode 48).
- Added regression assertions and preflight coverage for the stale-response lock race.
- Android APK build and physical-device testing remain pending.
