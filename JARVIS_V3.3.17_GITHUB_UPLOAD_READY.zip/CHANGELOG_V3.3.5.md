# JARVIS V3.3.5 — Android release consistency and build diagnostics

- Bumped Android `versionName` to `3.3.5` and `versionCode` to `37`.
- Updated all three visible MainActivity version labels to `V3.3.5`.
- Extended offline preflight to verify that the displayed app version matches the release metadata.
- Added `scripts/android_build_diagnostics.py` to report JDK, Gradle wrapper/executable, Android SDK path, and API 35 platform availability.
- No runtime task behavior or owner-approval policy was weakened.

Validation limitation: this environment has no Gradle executable/wrapper or configured Android SDK, so an APK build and Kotlin/Android compilation were not performed. The diagnostic reports these missing prerequisites rather than claiming an APK build.
