# JARVIS V3.3.15

- Updated Android version metadata to 3.3.15 (versionCode 47).
- GitHub Actions artifact name and build metadata now derive from Gradle version metadata to avoid stale release labels.
- Prepared a clean repository ZIP for phone upload, excluding Python caches and local runtime database files.
- APK build and physical-device testing remain pending until the cloud workflow is run.
