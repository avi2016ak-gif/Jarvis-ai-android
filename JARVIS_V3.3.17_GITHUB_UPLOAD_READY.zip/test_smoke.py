import os, tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings

fd, path = tempfile.mkstemp(); os.close(fd)
try:
    j = Jarvis(Settings(db_path=path, owner_id="me"))
    j.remember("language", "Kannada + English")
    assert j.recall("language") == "Kannada + English"
    assert j.status()["security"] == "owner-only"
    print("SMOKE TEST: PASS")
finally:
    os.remove(path)
