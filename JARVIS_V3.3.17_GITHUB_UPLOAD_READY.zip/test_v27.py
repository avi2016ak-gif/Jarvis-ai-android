import os,tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings
fd,p=tempfile.mkstemp(); os.close(fd)
j=Jarvis(Settings(db_path=p,owner_id='owner'))
try:
    assert tuple(map(int, j.VERSION.split('.'))) >= (2, 8)
    assert tuple(map(int, j.status()['version'].split('.'))) >= (2, 8)
    assert j.autonomous('owner','remember mode=autonomous then recall mode') == [True, 'autonomous']
    assert tuple(map(int, j.autonomous('owner','run status')['runtime_version'].split('.'))) >= (2,8)
    media=j.inspect_media('owner','image',b'data',{'source':'camera'})
    assert media['kind']=='image' and media['analyzed'] is False
    try: j.inspect_media('bad','image',b'data'); raise AssertionError('security failed')
    except PermissionError: pass
    print('JARVIS V2.7 TEST: PASS')
finally:
    j.shutdown(); os.remove(p)
