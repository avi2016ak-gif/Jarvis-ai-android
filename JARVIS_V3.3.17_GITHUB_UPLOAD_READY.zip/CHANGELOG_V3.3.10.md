# JARVIS V3.3.10

- Updated Android app version to 3.3.10 (versionCode 42).
- Added workflow concurrency control to cancel superseded builds on the same ref.
- Kept GitHub Actions repository permission read-only.
- Added explicit debug build metadata and version-labelled APK artifact.
- Corrected Android README versionCode metadata.
- This remains source code; a successful cloud Gradle build and device installation are still required.
