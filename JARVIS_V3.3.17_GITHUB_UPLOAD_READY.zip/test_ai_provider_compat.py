import os
import tempfile
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings

fd, path = tempfile.mkstemp()
os.close(fd)
jarvis = Jarvis(Settings(db_path=path, owner_id='owner'))
try:
    jarvis.providers.register('legacy-fallback', lambda text: 'provider:' + text, priority=50)
    result = jarvis.respond('owner', 'hey jarvis hello')
    assert result.intent == 'chat'
    assert result.result == 'provider:hello'
    print('AI PROVIDER COMPATIBILITY TEST: PASS')
finally:
    jarvis.shutdown()
    os.remove(path)
