# JARVIS V3.3.14

- Added an explicit owner-triggered Lock JARVIS button. Locking hides the private interaction controls, clears the current input/last spoken answer, stops speech, cancels speech recognition, and returns the UI to PIN authentication.
- Unlocking restores the controls; saved notes, reminders, and local memory are retained.
- This is a source-only update; cloud APK build and physical-device validation remain pending.
