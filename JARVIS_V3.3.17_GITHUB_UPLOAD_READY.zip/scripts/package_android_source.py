#!/usr/bin/env python3
"""Create a clean JARVIS Android source ZIP without runtime/local artifacts."""
from pathlib import Path
import argparse
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT.parent / "JARVIS_V3.3.17_ANDROID_SOURCE.zip"
EXCLUDED_DIRS = {"__pycache__", ".pytest_cache", ".git", ".gradle", "build"}
EXCLUDED_NAMES = {"jarvis_memory.db", "local.properties"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".db", ".sqlite", ".sqlite3"}
EXCLUDED_PREFIXES = (".env",)


def excluded(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return True
    if path.name in EXCLUDED_NAMES or path.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if any(path.name.startswith(prefix) for prefix in EXCLUDED_PREFIXES):
        return True
    if rel.parts[:2] == ("android", "app") and "build" in rel.parts:
        return True
    return False


def package(output: Path) -> int:
    output.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and not excluded(p))
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for file in files:
            zf.write(file, file.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(output) as zf:
        names = zf.namelist()
        bad = [n for n in names if Path(n).name == "jarvis_memory.db" or "__pycache__/" in n or n.endswith(".pyc") or n.endswith(".db")]
        if bad:
            output.unlink(missing_ok=True)
            raise RuntimeError(f"Unsafe runtime/cache artifacts found in package: {bad}")
        if zf.testzip() is not None:
            output.unlink(missing_ok=True)
            raise RuntimeError("ZIP integrity test failed")
    print(f"SOURCE ZIP: {output}\nFILES: {len(files)}\nSIZE: {output.stat().st_size} bytes\nZIP integrity and package hygiene: PASS")
    return len(files)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    package(args.output)
