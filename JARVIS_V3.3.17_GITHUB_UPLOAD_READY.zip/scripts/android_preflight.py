#!/usr/bin/env python3
"""Offline preflight checks for the JARVIS Android source package.

This is deliberately not an APK build or a substitute for Gradle/Kotlin tests.
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "android"
checks = []

def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

required = [
    "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/jarvis/assistant/MainActivity.kt",
    "app/src/main/java/com/jarvis/assistant/OwnerPermissionGate.kt",
    "app/src/main/java/com/jarvis/assistant/TaskHandlerRegistry.kt",
    "app/src/main/java/com/jarvis/assistant/JarvisBackgroundWorker.kt",
    "app/src/main/java/com/jarvis/assistant/JarvisReminderWorker.kt",
]
missing = [x for x in required if not (ANDROID / x).is_file()]
check("Required Android source files", not missing, ", ".join(missing))

build = (ANDROID / "app/build.gradle").read_text()
root_build = (ANDROID / "build.gradle").read_text()
check("Android Gradle Plugin pinned", "com.android.application' version '8.7.3'" in root_build)
check("Kotlin plugin pinned", "org.jetbrains.kotlin.android' version '2.0.21'" in root_build)
check("Chaquopy plugin pinned", "com.chaquo.python' version '16.0.0'" in root_build)
check("Android versionName is 3.3.17", bool(re.search(r"versionName\s+'3\.3\.17'", build)))
check("Android versionCode is 49", bool(re.search(r"versionCode\s+49\b", build)))
check("Java/Kotlin target is 17", "VERSION_17" in build and "jvmTarget = '17'" in build)
check("Chaquopy Python runtime is 3.10", "version = '3.10'" in build)

manifest_path = ANDROID / "app/src/main/AndroidManifest.xml"
ns = {"a": "http://schemas.android.com/apk/res/android"}
try:
    manifest = ET.parse(manifest_path).getroot()
    app = manifest.find("application")
    check("Manifest parses", True)
    check("Backup disabled", app is not None and app.get("{http://schemas.android.com/apk/res/android}allowBackup") == "false")
    check("Cleartext traffic disabled", app is not None and app.get("{http://schemas.android.com/apk/res/android}usesCleartextTraffic") == "false")
    perms = {e.get("{http://schemas.android.com/apk/res/android}name") for e in manifest.findall("uses-permission")}
    check("Microphone permission declared", "android.permission.RECORD_AUDIO" in perms)
    check("Notification permission declared", "android.permission.POST_NOTIFICATIONS" in perms)
    check("Internet permission declared for research/provider access", "android.permission.INTERNET" in perms)
except ET.ParseError as exc:
    check("Manifest parses", False, str(exc))

worker = (ANDROID / "app/src/main/java/com/jarvis/assistant/JarvisBackgroundWorker.kt").read_text()
check("Unconfigured background work fails closed", "STATUS_BLOCKED" in worker and "Result.failure()" in worker and "No approved task handler" in worker)
registry = (ANDROID / "app/src/main/java/com/jarvis/assistant/TaskHandlerRegistry.kt").read_text()
check("Unknown task types are blocked", "STATUS_BLOCKED_NO_HANDLER" in registry and "registeredHandlers[action.type]" in registry)

activity = (ANDROID / "app/src/main/java/com/jarvis/assistant/MainActivity.kt").read_text()
check("Visible app version matches release", activity.count("V3.3.17") >= 3 and "V3.3.2" not in activity)
check("Manual lock returns to PIN and clears transient answer", "private fun lockJarvis()" in activity and "lastAnswer = \"\"" in activity and "pin.visibility = View.VISIBLE" in activity)
check("Lock button wired and hidden while locked", "lockButton.setOnClickListener { lockJarvis() }" in activity and "lockButton.visibility = View.GONE" in activity)
check("Late AI responses are discarded after lock", "requestGeneration += 1" in activity and "if (!unlocked || generation != requestGeneration) return@runOnUiThread" in activity)

workflow = (ROOT / ".github/workflows/android-build.yml")
check("GitHub Actions Android build workflow present", workflow.is_file())
if workflow.is_file():
    workflow_text = workflow.read_text()
    check("Cloud workflow validates Gradle project configuration", "gradle --no-daemon help" in workflow_text)
    check("Cloud workflow records Gradle version", "gradle --version" in workflow_text)
    check("Cloud workflow runs Gradle assembleDebug", "gradle --no-daemon assembleDebug" in workflow_text)
    check("Cloud workflow uploads APK artifact", "app-debug.apk" in workflow_text and "actions/upload-artifact" in workflow_text)
    check("Cloud workflow installs Android 35 platform", "platforms;android-35" in workflow_text)
    check("Cloud workflow installs Build Tools 35", "build-tools;35.0.0" in workflow_text)
    check("Cloud workflow runs Android unit tests", "testDebugUnitTest" in workflow_text)
check("Phone-friendly cloud build instructions present", (ROOT / "BUILD_ON_GITHUB.md").is_file())
if workflow.is_file():
    check("Cloud workflow has read-only repository permission", "contents: read" in workflow_text)
    check("Cloud workflow prevents duplicate concurrent runs", "cancel-in-progress: true" in workflow_text)
    check("Cloud workflow records debug build type", "BUILD_TYPE=debug" in workflow_text)
    check("Cloud artifact is version-labelled", "artifact=jarvis-v$VERSION-debug-apk" in workflow_text)

tests = list((ANDROID / "app/src/test/java/com/jarvis/assistant").glob("*Test.kt"))
check("Kotlin unit test sources present", len(tests) >= 4, f"{len(tests)} test files")
# Keep accidental local runtime data and generated caches out of release-source packaging.
package_script = (ROOT / "scripts/package_android_source.py").read_text()
check("Source packager excludes runtime database files", "EXCLUDED_SUFFIXES" in package_script and ".db" in package_script and "jarvis_memory.db" in package_script)
check("Python bytecode/cache excluded from source tree", not any(ROOT.rglob("*.pyc")) and not any(ROOT.rglob("__pycache__")))

failed = 0
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}" + (f" — {detail}" if detail else ""))
    failed += not ok
print(f"ANDROID PREFLIGHT: {len(checks)-failed}/{len(checks)} checks passed")
if failed:
    sys.exit(1)
