#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT/android/app/src/main/python:$ROOT${PYTHONPATH:+:$PYTHONPATH}"
echo '[1/4] Running Android source preflight...'
python scripts/android_preflight.py
echo '[2/4] Compiling and testing Android-independent Kotlin core...'
bash scripts/kotlin_core_smoke.sh
echo '[3/4] Running pytest suite...'
python -m pytest -q
echo '[4/4] Running legacy compatibility scripts...'
for test_file in \
  test_v21.py test_v22.py test_v23.py test_v24.py test_v25.py \
  test_v26.py test_v27.py test_v28.py test_v29.py test_v30.py \
  test_smoke.py test_integration.py test_ai_provider_compat.py test_android_bridge.py
do
  printf ' - %s: ' "$test_file"
  python "$test_file" >/dev/null
  echo PASS
done
echo 'ALL KOTLIN AND PYTHON TESTS PASSED'
