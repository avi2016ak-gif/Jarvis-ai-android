#!/usr/bin/env python3
"""Report whether this environment has the prerequisites to build the Android APK."""
from pathlib import Path
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "android"
checks = []

def add(label, ok, detail):
    checks.append((label, ok, detail))

java = shutil.which("java")
if java:
    try:
        result = subprocess.run([java, "-version"], capture_output=True, text=True, timeout=10)
        version_text = result.stderr + result.stdout
        import re
        match = re.search(r'version "(?:1\.)?(\d+)', version_text)
        major = int(match.group(1)) if match else 0
        add("JDK 17 or newer", major >= 17, f"detected Java {major}")
    except Exception as exc:
        add("JDK 17 or newer", False, str(exc))
else:
    add("JDK 17 or newer", False, "java executable not found")

kotlinc = shutil.which("kotlinc")
add("Kotlin compiler (standalone core checks)", bool(kotlinc), kotlinc or "kotlinc executable not found")

wrapper = ANDROID / "gradlew"
add("Gradle wrapper", wrapper.is_file(), "android/gradlew present" if wrapper.is_file() else "android/gradlew is missing")
gradle = shutil.which("gradle")
add("Gradle executable", bool(gradle), gradle or "gradle executable not found")
sdk = os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
add("Android SDK path", bool(sdk and Path(sdk).exists()), sdk or "ANDROID_SDK_ROOT / ANDROID_HOME is not configured")
if sdk and Path(sdk).exists():
    add("Android platform 35", (Path(sdk) / "platforms/android-35/android.jar").is_file(), str(Path(sdk) / "platforms/android-35"))
else:
    add("Android platform 35", False, "cannot inspect platform without an SDK path")

for label, ok, detail in checks:
    print(f"{'READY' if ok else 'BLOCKED'}: {label} — {detail}")
ready = sum(ok for _, ok, _ in checks)
print(f"BUILD READINESS: {ready}/{len(checks)} prerequisites available")
if ready != len(checks):
    print("APK build not attempted: required Android build tooling is incomplete.")
    sys.exit(2)
print("All prerequisites detected. Run ./gradlew assembleDebug from the android directory.")
