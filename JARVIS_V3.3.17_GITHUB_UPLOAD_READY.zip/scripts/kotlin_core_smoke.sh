#!/usr/bin/env bash
# Compile and execute Android-independent Kotlin safety/task core without Android SDK.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/android/app/src/main/java/com/jarvis/assistant"
KOTLINC_BIN="$(command -v kotlinc || true)"
if [[ -z "$KOTLINC_BIN" ]]; then
  echo "BLOCKED: kotlinc executable not found"
  exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/CoreSmoke.kt" <<'KOTLIN'
package com.jarvis.assistant

private class MemoryStore : LocalTaskStore {
    private val rows = mutableListOf<String>()
    override fun append(kind: String, value: String, createdAtMillis: Long): String {
        val id = "test-${rows.size + 1}"
        rows.add("$kind:$value:$createdAtMillis")
        return id
    }
    override fun list(kind: String): List<String> = rows.filter { it.startsWith("$kind:") }
}

fun main() {
    var now = 1_000L
    val gate = OwnerPermissionGate(nowMillis = { now }, expiryMillis = 100L)
    check(gate.request("SAVE_NOTE", "test note").contains("OWNER APPROVAL REQUIRED"))
    check(gate.pendingType() == "SAVE_NOTE")
    check(gate.request("DELETE_FILES", "delete files").contains("ALREADY PENDING"))
    check(gate.approve()?.description == "test note")
    check(gate.pendingDescription() == null)

    gate.request("SAVE_NOTE", "deny me")
    check(gate.deny())
    check(!gate.deny())
    gate.request("SAVE_NOTE", "expire me")
    now += 101L
    check(gate.pendingDescription() == null)

    val store = MemoryStore()
    val registry = LocalTaskHandlers(store) { now }.asRegistry()
    val unknown = registry.execute(ProtectedAction("DELETE_FILES", "delete", now))
    check(!unknown.successful && unknown.status == TaskHandlerRegistry.STATUS_BLOCKED_NO_HANDLER)
    val saved = registry.execute(ProtectedAction(LocalTaskHandlers.TYPE_SAVE_NOTE, "  hello Jarvis  ", now))
    check(saved.successful && saved.status == LocalTaskHandlers.STATUS_SAVED)
    check(store.list(LocalTaskHandlers.TYPE_SAVE_NOTE).single().contains(":hello Jarvis:"))
    val empty = registry.execute(ProtectedAction(LocalTaskHandlers.TYPE_SAVE_NOTE, "   ", now))
    check(!empty.successful && empty.status == LocalTaskHandlers.STATUS_INVALID)
    println("KOTLIN CORE SMOKE: 10 assertions PASS")
}
KOTLIN
"$KOTLINC_BIN" \
  "$SRC/OwnerPermissionGate.kt" \
  "$SRC/TaskHandlerRegistry.kt" \
  "$SRC/LocalTaskHandlers.kt" \
  "$TMP/CoreSmoke.kt" \
  -include-runtime -d "$TMP/core-smoke.jar"
java -jar "$TMP/core-smoke.jar"
