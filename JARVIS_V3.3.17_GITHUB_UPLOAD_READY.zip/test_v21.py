import os,tempfile,time
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings
from jarvis.voice.wakeword import WakeWordDetector
fd,p=tempfile.mkstemp();os.close(fd)
j=Jarvis(Settings(db_path=p,owner_id="me"))
try:
 assert j.wakeword.detect("Hey Jarvis, status")
 assert j.execute("me","math",lambda:2+3)==5
 assert j.recall("x") is None
 j.remember("x","ok"); assert j.recall("x")=="ok"
 done=[]; j.scheduler.schedule("test",0.1,lambda:done.append(1)); time.sleep(.3); assert done==[1]
 assert j.audit.all()[-1]["allowed"] is True
 print("JARVIS V2.1 TEST: PASS")
finally:
 j.scheduler.shutdown(); j.tasks.shutdown(); os.remove(p)
