# JARVIS V3.3.12

- Added Android INTERNET permission to support HTTPS research and provider networking.
- Kept cleartext traffic disabled.
- Updated Android versionName to 3.3.12 and versionCode to 44.
- Added preflight validation for the INTERNET permission and updated cloud build artifact metadata.
- Source-level validation only; APK build and physical-device testing remain pending.
