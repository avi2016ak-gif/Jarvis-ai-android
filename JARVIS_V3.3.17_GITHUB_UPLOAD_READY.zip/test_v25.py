import os,tempfile,time
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings
fd,p=tempfile.mkstemp(); os.close(fd)
j=Jarvis(Settings(db_path=p,owner_id='owner'))
try:
    assert j.VERSION >= '2.5'
    assert all(x['ok'] for x in j.health_status())
    j.providers.register('fallback',lambda text:'provider:'+text)
    assert j.respond('owner','hey jarvis hello').result=='provider:hello'
    f=j.tasks.submit('owner','async',lambda:'done'); assert j.tasks.result(f.task_id).value=='done'
    assert j.respond('owner','status').intent=='status'
    print('JARVIS V2.5 TEST: PASS')
finally:
    j.shutdown(); os.remove(p)
