import os,tempfile,time
from jarvis.core.assistant import Jarvis
from jarvis.config.settings import Settings
fd,p=tempfile.mkstemp(); os.close(fd)
j=Jarvis(Settings(db_path=p, owner_id='owner'))
try:
    j.providers.register('fallback', lambda text: 'provider:'+text, priority=50)
    assert j.respond('owner','hey jarvis hello').result == 'provider:hello'
    t=j.scheduler.schedule('cancelled',1,lambda: (_ for _ in ()).throw(AssertionError()))
    assert j.scheduler.cancel(t.task_id)
    t2=j.scheduler.schedule('run',0.05,lambda: None); time.sleep(.15)
    assert all(x.task_id != t2.task_id for x in j.scheduler.pending())
    assert 'providers' in j.status()
    print('JARVIS V2.4 TEST: PASS')
finally:
    j.shutdown(); os.remove(p)
