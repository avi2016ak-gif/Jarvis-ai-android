# JARVIS V3.3.2 — local task and reminder integration

- Integrated the v0.9 local task store, allow-listed task registry, fail-closed owner approval gate, and task manager into the V3.3.1 Android source.
- Preserved the V3.3.1 Python/Chaquopy core and its app-private SQLite bridge; task commands are routed locally only when they match the explicit allow-list.
- Added per-action owner PIN re-entry before approving a protected action; pending requests expire after five minutes and a second request cannot replace one already pending.
- Added locally stored notes and reminders, reminder edit/cancel by stored ID, and WorkManager one-time reminder notifications.
- Added notification permission handling and Java time core-library desugaring while retaining minSdk 24.
- Added four Kotlin unit-test suites from v0.9 and Python static integration checks.
- Background-task requests are owner-gated and queued, but the worker intentionally reports `BLOCKED_HANDLER_NOT_CONFIGURED`; arbitrary text is never executed as code.
- No APK build or Android-device validation is claimed: this environment has no Android SDK/Gradle installation.

## V3.3.3 — validation workflow
- Added a single test runner at `scripts/run_tests.sh`.
- Verified 8 pytest tests and 14 legacy Python/bridge compatibility scripts pass in the development environment.
- No Android APK build is claimed: this environment does not have the Android SDK or a Gradle executable/wrapper available. Physical-device testing remains required.
