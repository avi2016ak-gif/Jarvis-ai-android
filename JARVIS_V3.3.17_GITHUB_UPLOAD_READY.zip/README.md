# JARVIS V3.3 — Android integration source

This build preserves the V3.1 Python assistant core and adds an initial native Android application project under `android/`.

## Python core
Run `python main.py` from this folder. Run `./scripts/run_tests.sh` from this folder to execute the pytest suite and all legacy compatibility scripts. The script sets the Android Python bridge import path automatically.

## Android app source
Open the `android/` folder in Android Studio with JDK 17 and Android SDK 35 installed. The app embeds the Python core using Chaquopy 16.0.0 and stores its SQLite memory in the app-private files directory. See `android/README.md` for build steps and limitations.

**Important:** this is Android source code, not a compiled APK. An Android SDK/Gradle build and real-device validation have not been performed in this environment. Voice/wake-word background operation, camera integration, hardened owner authentication, and production security testing remain outstanding.


Android update: native source now uses salted PBKDF2 PIN derivation and the Python bridge no longer accepts a caller-supplied actor ID. Android APK compilation and device validation remain pending.

V3.3 Android update: persistent failed-PIN lockout across app restarts and Kannada/English voice-language toggle. Android APK compilation/device validation remain pending.

## Android V3.3.6 update
The Android source includes the v0.9 local task/reminder modules integrated alongside the V3.3.1 Python/Chaquopy core. V3.3.6 adds direct Kotlin compiler/runtime checks for the Android-independent owner gate and allow-listed task handlers. V3.3.5 fixes the app-visible version label and adds a build-readiness diagnostic. Protected local actions require explicit owner approval and a fresh PIN entry. Reminder scheduling uses WorkManager. Background-task workers remain intentionally blocked until reviewed handlers are implemented. See `android/README.md` and `CHANGELOG_V3.3.2.md`. This is still source-only; APK build and physical-device validation remain outstanding.


## V3.3.3 validation helper update
- Added `scripts/run_tests.sh` as a single repeatable entry point for the pytest suite and legacy compatibility scripts.
- This does not change runtime behavior or claim Android build/device validation.


## V3.3.12 update
- Android INTERNET permission added for HTTPS research/provider access; cleartext traffic remains disabled. APK build and device validation pending.

## V3.3.13 update
- Research output formatted for phone readability, with source links and an explicit warning that lexical source overlap is not independent fact verification. APK/device validation pending.

## V3.3.15 update
- Added manual owner lock: clears transient input/answer, stops speech, cancels recognition, and returns to PIN screen while preserving local notes/reminders/memory. Version metadata 3.3.15 (versionCode 47). APK/device validation pending.

## Tests and build status
- `bash scripts/run_tests.sh`: Android source preflight, standalone Kotlin safety-core smoke, pytest suite, and legacy compatibility checks.
- Android APK build and physical-device validation have not yet happened. Cloud workflow is available through GitHub Actions; see `BUILD_ON_GITHUB.md`.


## V3.3.15 release preparation
- Version metadata 3.3.15 (versionCode 47). Cloud workflow derives APK artifact/version metadata from Gradle. Source package excludes runtime DB/cache files. APK/device validation pending.


## V3.3.17 update
- Fixed a lock-session race: AI responses queued or in flight before owner lock are now discarded and cannot repopulate cleared output after lock.
- Version metadata 3.3.17 (versionCode 49). Source checks pass; Android Gradle APK build and physical-device validation remain pending.


## V3.3.17 update
- Source packaging hygiene: removed test runtime SQLite database and added preflight checks to prevent database/cache artifacts from being included.
- Version metadata 3.3.17 (versionCode 49). APK build and device validation pending.
- Added `scripts/package_android_source.py`, a repeatable source ZIP packager that excludes runtime databases, secrets, caches, bytecode, local Android properties, and build output, then validates ZIP integrity.
