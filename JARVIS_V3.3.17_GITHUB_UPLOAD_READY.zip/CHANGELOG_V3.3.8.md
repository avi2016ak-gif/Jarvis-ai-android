# JARVIS V3.3.8

- Updated Android app version to 3.3.8 (versionCode 40).
- Cloud workflow explicitly installs Android SDK Platform 35, Platform Tools, and Build Tools 35.0.0.
- Cloud workflow now runs Android Gradle unit tests before building the debug APK.
- Preflight checks verify the SDK installation and unit-test steps are present in the workflow.
- Preserved the Owner Permission Gate and fail-closed unknown-task handling.
- This workflow has not yet been run remotely; no APK build success is claimed.
