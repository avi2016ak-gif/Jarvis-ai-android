# JARVIS V3.3.1

## Implemented in this source update
- Fixed the Chaquopy Android bridge to instantiate the core with an explicit SQLite path inside Android's private files directory.
- Removed fragile environment-variable timing from bridge startup.
- Safely shuts down an existing core instance before reinitialization.
- Added automated bridge tests covering startup, persistent DB file placement, status response, and pre-initialization rejection.
- Android app version incremented to 3.3.1 (versionCode 34).

## Verification
- Python pytest suite: 6 passed.
- Legacy standalone core checks: run separately and recorded below in the delivery note.
- APK build/device verification: not performed; Gradle executable/wrapper and Android SDK are not available in this environment.

## Remaining production work
- Full Android SDK/Gradle build and install test on the target Oppo phone.
- Keystore-backed owner authentication and independent owner shutdown.
- Actual camera/image analysis provider and real online research provider validation.
- Always-on wake-word/background service and persistent background task execution.
- Merge/reconcile the separate v0.9 reminder/task implementation with this V3.3 Android app without losing either feature set.
- Security, privacy, battery, offline, and end-to-end testing.
